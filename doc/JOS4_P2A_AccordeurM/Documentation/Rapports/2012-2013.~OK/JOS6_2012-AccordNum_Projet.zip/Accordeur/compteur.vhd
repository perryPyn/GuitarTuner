----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date:    13:40:07 10/16/2012 
-- Design Name: 
-- Module Name:    compteur - Behavioral 
-- Project Name: 
-- Target Devices: 
-- Tool versions: 
-- Description: 
--
-- Dependencies: 
--
-- Revision: 
-- Revision 0.01 - File Created
-- Additional Comments: 
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

ENTITY Compteur IS
PORT (
  clk,InitCompt,ValidCompt,SensCroiss :IN std_logic;
  qs : OUT std_logic_vector(6 downto 0) := "0000000");
  
  
END Compteur;

ARCHITECTURE Cmpt OF Compteur IS
SIGNAL q : std_logic_vector(6 downto 0):= "0000000"; 
BEGIN
  qs <= q;
  PROCESS(clk) BEGIN
    IF clk' event and clk='1'  THEN
		IF InitCompt='1' THEN
		q <= "1100100";
		
      ELSIF ValidCompt='1' THEN
		  IF SensCroiss='1' OR q = "0000000" THEN 
        q<=q+1;
		  ELSIF q /= "0000000" THEN
		  q<=q-1;
        END IF;
		END IF;
	 END IF;
  END PROCESS;
END Cmpt;


