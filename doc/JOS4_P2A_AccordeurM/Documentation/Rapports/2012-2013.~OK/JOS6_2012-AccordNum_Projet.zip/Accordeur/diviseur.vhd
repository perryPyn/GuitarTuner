----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date:    13:44:08 12/18/2012 
-- Design Name: 
-- Module Name:    diviseur - Behavioral 
-- Project Name: 
-- Target Devices: 
-- Tool versions: 
-- Description: 
--
-- Dependencies: 
--
-- Revision: 
-- Revision 0.01 - File Created
-- Additional Comments: 
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

---- Uncomment the following library declaration if instantiating
---- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity diviseur is
    Port ( FreqVar : in  STD_LOGIC;
           Mesure : out  STD_LOGIC := '0');
end diviseur;

architecture Behavioral of diviseur is
SIGNAL q : STD_LOGIC_VECTOR(7 downto 0):= "00000000";

begin

	process(FreqVar) 
	begin
    if (FreqVar' event and FreqVar = '1') then
		  q <= q + '1';
		
	 end if;
  end process;

Mesure <= '0' when (q >= "1100100" ) else
          '1';

end Behavioral;
