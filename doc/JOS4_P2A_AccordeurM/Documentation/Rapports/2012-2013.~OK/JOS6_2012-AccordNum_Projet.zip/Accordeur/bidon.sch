VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "xbr"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL e
        SIGNAL s
        PORT Input e
        PORT Output s
        BEGIN BLOCKDEF inv
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -32 64 -32 
            LINE N 224 -32 160 -32 
            LINE N 64 -64 128 -32 
            LINE N 128 -32 64 0 
            LINE N 64 0 64 -64 
            CIRCLE N 128 -48 160 -16 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 inv
            PIN I e
            PIN O s
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 3520 2720
        INSTANCE XLXI_1 1248 992 R0
        BEGIN BRANCH e
            WIRE 1216 960 1248 960
        END BRANCH
        IOMARKER 1216 960 e R180 28
        BEGIN BRANCH s
            WIRE 1472 960 1504 960
        END BRANCH
        IOMARKER 1504 960 s R0 28
    END SHEET
END SCHEMATIC
