--------------------------------------------------------------------------------
-- Copyright (c) 1995-2007 Xilinx, Inc.  All rights reserved.
--------------------------------------------------------------------------------
--   ____  ____ 
--  /   /\/   / 
-- /___/  \  /    Vendor: Xilinx 
-- \   \   \/     Version : 9.2.04i
--  \   \         Application : sch2vhdl
--  /   /         Filename : Accordeur.vhf
-- /___/   /\     Timestamp : 05/28/2013 16:01:46
-- \   \  /  \ 
--  \___\/\___\ 
--
--Command: C:\PROGRAMS\Xilinx92i\bin\nt\sch2vhdl.exe -intstyle ise -family xbr -flat -suppress -w U:/Windows/Documents/Accordeur/Accordeur.sch Accordeur.vhf
--Design Name: Accordeur
--Device: xbr
--Purpose:
--    This vhdl netlist is translated from an ECS schematic. It can be 
--    synthesis and simulted, but it should not be modified. 
--

library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
library UNISIM;
use UNISIM.Vcomponents.ALL;

entity Accordeur is
   port ( FreqRef : in    std_logic; 
          FreqVar : in    std_logic; 
          Ecart   : out   std_logic_vector (6 downto 0); 
          Signe   : out   std_logic);
end Accordeur;

architecture BEHAVIORAL of Accordeur is
   signal EtatZero   : std_logic;
   signal FreqVarDiv : std_logic;
   signal InitCompt  : std_logic;
   signal QS         : std_logic_vector (6 downto 0);
   signal SensCroiss : std_logic;
   signal ValidCompt : std_logic;
   signal XLXN_28    : std_logic;
   component sequenceur
      port ( Mesure     : in    std_logic; 
             Etat_0     : in    std_logic; 
             FreqRef    : in    std_logic; 
             InitCompt  : out   std_logic; 
             ValidCompt : out   std_logic; 
             SensCroiss : out   std_logic; 
             ChargReg   : out   std_logic);
   end component;
   
   component diviseur
      port ( FreqVar : in    std_logic; 
             Mesure  : out   std_logic);
   end component;
   
   component Compteur
      port ( clk        : in    std_logic; 
             InitCompt  : in    std_logic; 
             ValidCompt : in    std_logic; 
             SensCroiss : in    std_logic; 
             qs         : out   std_logic_vector (6 downto 0));
   end component;
   
   component registre
      port ( FreqRef        : in    std_logic; 
             ChargReg       : in    std_logic; 
             SensCroiss     : in    std_logic; 
             Reg            : in    std_logic_vector (6 downto 0); 
             SensCroiss_out : out   std_logic; 
             Reg_out        : out   std_logic_vector (6 downto 0));
   end component;
   
   component etat_0
      port ( e      : in    std_logic_vector (6 downto 0); 
             Etat_0 : out   std_logic);
   end component;
   
begin
   XLXI_1 : sequenceur
      port map (Etat_0=>EtatZero,
                FreqRef=>FreqRef,
                Mesure=>FreqVarDiv,
                ChargReg=>XLXN_28,
                InitCompt=>InitCompt,
                SensCroiss=>SensCroiss,
                ValidCompt=>ValidCompt);
   
   XLXI_2 : diviseur
      port map (FreqVar=>FreqVar,
                Mesure=>FreqVarDiv);
   
   XLXI_8 : Compteur
      port map (clk=>FreqRef,
                InitCompt=>InitCompt,
                SensCroiss=>SensCroiss,
                ValidCompt=>ValidCompt,
                qs(6 downto 0)=>QS(6 downto 0));
   
   XLXI_9 : registre
      port map (ChargReg=>XLXN_28,
                FreqRef=>FreqRef,
                Reg(6 downto 0)=>QS(6 downto 0),
                SensCroiss=>SensCroiss,
                Reg_out(6 downto 0)=>Ecart(6 downto 0),
                SensCroiss_out=>Signe);
   
   XLXI_10 : etat_0
      port map (e(6 downto 0)=>QS(6 downto 0),
                Etat_0=>EtatZero);
   
end BEHAVIORAL;


