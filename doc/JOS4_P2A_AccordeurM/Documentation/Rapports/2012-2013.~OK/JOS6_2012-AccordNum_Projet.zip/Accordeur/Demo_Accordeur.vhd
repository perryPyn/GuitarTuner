--------------------------------------------------------------------------------
-- Copyright (c) 1995-2007 Xilinx, Inc.  All rights reserved.
--------------------------------------------------------------------------------
--   ____  ____ 
--  /   /\/   / 
-- /___/  \  /    Vendor: Xilinx 
-- \   \   \/     Version : 9.2.04i
--  \   \         Application : sch2vhdl
--  /   /         Filename : Demo_Accordeur.vhf
-- /___/   /\     Timestamp : 05/27/2013 14:01:35
-- \   \  /  \ 
--  \___\/\___\ 
--
--Command: C:\PROGRAMS\Xilinx92i\bin\nt\sch2vhdl.exe -intstyle ise -family xbr -flat -suppress -w U:/Windows/Documents/Accordeur/Demo_Accordeur.sch Demo_Accordeur.vhf
--Design Name: Demo_Accordeur
--Device: xbr
--Purpose:
--    This vhdl netlist is translated from an ECS schematic. It can be 
--    synthesis and simulted, but it should not be modified. 
--

library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
library UNISIM;
use UNISIM.Vcomponents.ALL;

entity Demo_Accordeur is
   port ( e_clk     : in    std_logic; 
          e_freqvar : in    std_logic; 
          s_ecart   : out   std_logic_vector (6 downto 0); 
          s_signe   : out   std_logic);
end Demo_Accordeur;

architecture BEHAVIORAL of Demo_Accordeur is
   signal XLXN_2    : std_logic;
   component Accordeur
      port ( FreqVar : in    std_logic; 
             FreqRef : in    std_logic; 
             Ecart   : out   std_logic_vector (6 downto 0); 
             Signe   : out   std_logic);
   end component;
   
   component ClockDivider
      port ( C    : in    std_logic; 
             SCLK : out   std_logic);
   end component;
   
begin
   XLXI_1 : Accordeur
      port map (FreqRef=>XLXN_2,
                FreqVar=>e_freqvar,
                Ecart(6 downto 0)=>s_ecart(6 downto 0),
                Signe=>s_signe);
   
   XLXI_2 : ClockDivider
      port map (C=>e_clk,
                SCLK=>XLXN_2);
   
end BEHAVIORAL;


