----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date:    14:58:56 12/18/2012 
-- Design Name: 
-- Module Name:    sequenceur - Behavioral 
-- Project Name: 
-- Target Devices: 
-- Tool versions: 
-- Description: 
--
-- Dependencies: 
--
-- Revision: 
-- Revision 0.01 - File Created
-- Additional Comments: 
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

---- Uncomment the following library declaration if instantiating
---- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity sequenceur is
    Port ( Mesure : in  STD_LOGIC;
           Etat_0 : in  STD_LOGIC;
           FreqRef : in  STD_LOGIC;
           InitCompt : out  STD_LOGIC:='0';
           ValidCompt : out  STD_LOGIC:='0';
           SensCroiss : out  STD_LOGIC:='0';
           ChargReg : out  STD_LOGIC:='0');
end sequenceur;

architecture Behavioral of sequenceur is

Type etat is (attente, decrementation, incrementation, chargement_registre) ;
Signal present, futur : etat ;

Begin

-- Partie synchronis�e "REGISTRE"
	Process (FreqRef)
		Begin
		If (FreqRef' event and FreqRef = '1') then
			 present <= futur ;
		End if ;
	End process;

-- Partie combinatoire "ETAT FUTUR"
	Process (present, Mesure, Etat_0)
		Begin

		CASE present is

		WHEN attente =>
--			 ChargReg <='0';
--			 ValidCompt <= '0';
--			 InitCompt <= '1';
			 SensCroiss <='0';

			 IF (Mesure = '1') THEN 
				  futur <= decrementation;
			 ELSE 
				  futur <= attente;
			 END IF ;

		WHEN decrementation =>
--			 ChargReg <='0';
--			 ValidCompt <= '1';
--			 InitCompt <= '0';
			 SensCroiss <= '0';

			 IF (Etat_0 = '1') THEN 
				  futur <= incrementation;
			 ELSE 
			     IF (Mesure = '0') THEN 
				      futur <= chargement_registre;
			     ELSE 
				      futur <= decrementation;
					END IF ;
					
				END IF;
			 

		WHEN incrementation =>
--			 ChargReg <='0';
--			 ValidCompt <= '1';
--			 InitCompt <= '0';
			 SensCroiss <= '1';

			 IF (Mesure = '0') THEN 
				  futur <= chargement_registre;
			 ELSE 
				  futur <= incrementation;
			 END IF ;

		WHEN chargement_registre =>
--			 ChargReg <='1';
--			 ValidCompt <= '0';
--			 InitCompt <= '0';

			 futur <= attente;

		END CASE;
	END Process;


-- Partie combinatoire "SORTIES"

InitCompt <= '1' WHEN (present = attente) ELSE
             '0';

ChargReg <= '1' WHEN (present = chargement_registre) ELSE
				'0';

ValidCompt <= '1' WHEN ((present = incrementation) OR (present = decrementation)) ELSE	
				  '0';
	
----SensCroiss <= '1' WHEN (((present = decrementation) and (Etat_0 = '1')) OR
----	                        ((present = incrementation) and (Mesure = '1'))) ELSE
----	           '0';
--
----   SensCroiss <= '0' WHEN ((present = attente) OR (present = incrementation) OR (present = chargement_registre))ELSE
----	              '1';
--
----   SensCroiss <= '1' WHEN (((present = decrementation) and (Etat_0 = '1')) OR
----	                        ((present = incrementation) and (Mesure = '1'))) ELSE
----	              '0';
--
----	SensCroiss <= '1' WHEN (present = incrementation);
----	SensCroiss <= '0' WHEN ((present = attente) OR (present = decrementation));
	

END Behavioral;

