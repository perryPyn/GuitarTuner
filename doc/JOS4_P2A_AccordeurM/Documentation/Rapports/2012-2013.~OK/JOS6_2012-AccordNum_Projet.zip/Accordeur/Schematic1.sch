*version 16.2 1220289104
u 476
C? 14
V? 5
R? 23
HB? 3
U? 5
D? 5
@libraries
@analysis
@targets
@attributes
@translators
a 0 u 13 0 0 0 hln 100 PCBOARDS=PCB
a 0 u 13 0 0 0 hln 100 PSPICE=PSPICE
a 0 u 13 0 0 0 hln 100 XILINX=XILINX
@setup
unconnectedPins 0
connectViaLabel 0
connectViaLocalLabels 0
NoStim4ExtIFPortsWarnings 1
AutoGenStim4ExtIFPorts 1
@index
pageloc 1 0 9875 
pageloc 2 9875 2874 
@status
c 112:02:23:11:10:47;1332497447
*page 1 0 1520 970 ma
@ports
port 146 GND_EARTH 270 370 h
port 147 GND_EARTH 90 370 h
port 140 GND_EARTH 380 370 h
port 141 GND_EARTH 520 370 h
port 149 +5V 450 330 v
a 1 x 3 0 0 0 hcn 100 LABEL=Vcc
port 142 GND_EARTH 570 370 h
port 143 GND_EARTH 590 370 h
port 150 +5V 340 120 h
a 1 x 3 0 0 0 hcn 100 LABEL=Vcc
port 148 GND_EARTH 340 210 h
port 114 GND_ANALOG 430 240 d
port 144 GND_EARTH 550 290 h
port 145 GND_EARTH 550 290 u
port 208 GND_EARTH 590 190 h
port 151 +5V 560 160 h
a 1 x 3 0 0 0 hcn 100 LABEL=Vcc
port 212 +5V 640 240 h
a 1 x 3 0 0 0 hcn 100 LABEL=VL
port 316 GND_EARTH 890 130 u
port 315 GND_EARTH 890 290 h
@parts
part 12 c 130 280 h
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C1
a 0 ap 9 0 15 0 hln 100 REFDES=C1
part 13 vdc 120 300 h
a 1 u 13 0 -11 18 hcn 100 DC=9v
a 0 sp 0 0 22 37 hln 100 PART=vdc
a 0 a 0:13 0 0 0 hln 100 PKGREF=V1
a 1 ap 9 0 24 7 hcn 100 REFDES=V1
part 32 c 220 280 h
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C2
a 0 ap 9 0 15 0 hln 100 REFDES=C2
part 33 r 270 340 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R1
a 0 ap 9 0 15 0 hln 100 REFDES=R1
part 49 c 330 280 h
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C3
a 0 ap 9 0 15 0 hln 100 REFDES=C3
part 55 r 380 320 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R4
a 0 ap 9 0 15 0 hln 100 REFDES=R4
part 58 r 500 330 u
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R7
a 0 ap 9 0 15 0 hln 100 REFDES=R7
part 56 r 450 320 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R5
a 0 ap 9 0 15 0 hln 100 REFDES=R5
part 83 c 520 330 d
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C7
a 0 ap 9 0 15 0 hln 100 REFDES=C7
part 54 r 340 150 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R3
a 0 ap 9 0 15 0 hln 100 REFDES=R3
part 53 r 340 210 v
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R2
a 0 ap 9 0 15 0 hln 100 REFDES=R2
part 57 r 470 240 u
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R6
a 0 ap 9 0 15 0 hln 100 REFDES=R6
block 115 blocksym115 470 210 h
a 0 x 0:13 0 0 0 hln 100 PKGREF=XR4151-FVC
a 0 xp 9 0 0 0 hln 100 REFDES=XR4151-FVC
*symbol blocksym115
d 
@type p
@attributes
a 0 sp 9 0 0 0 hln 100 REFDES=HB?
a 0 s 0 0 0 0 hln 100 PART=
@pins
p 2 2 54 hlb 100 P1 l 0 50 h
a 0 s 0:13 0 0 -20 hln 100 ERC=i
a 0 s 0:13 0 0 -20 hln 100 FLOAT=n
p 2 2 74 hlb 100 P2 l 0 70 h
a 0 s 0:13 0 0 -20 hln 100 ERC=i
a 0 s 0:13 0 0 -20 hln 100 FLOAT=n
p 2 50 80 hcb 100 P4 l 50 80 v
a 0 s 0:13 0 0 -20 hln 100 ERC=i
a 0 s 0:13 0 0 -20 hln 100 FLOAT=n
p 2 110 80 hcb 100 P7 l 110 80 v
a 0 s 0:13 0 0 -20 hln 100 ERC=i
a 0 s 0:13 0 0 -20 hln 100 FLOAT=n
p 2 80 80 hcb 100 P6 l 80 80 v
a 0 s 0:13 0 0 -20 hln 100 ERC=i
a 0 s 0:13 0 0 -20 hln 100 FLOAT=n
p 2 2 34 hlb 100 P10 l 0 30 h
a 0 s 0:13 0 0 -10 hln 100 ERC=i
a 0 s 0:13 0 0 -10 hln 100 FLOAT=n
p 2 90 0 hct 100 P8 l 90 0 d
a 0 s 0:13 0 0 0 hln 100 ERC=i
a 0 s 0:13 0 0 0 hln 100 FLOAT=n
p 2 128 74 hrb 100 P9 l 130 70 u
a 0 s 0:13 0 0 0 hln 100 ERC=o
a 0 s 0:13 0 0 0 hln 100 FLOAT=n
p 2 2 14 hlb 100 P11 l 0 10 h
a 0 s 0:13 0 0 0 hln 100 ERC=i
a 0 s 0:13 0 0 0 hln 100 FLOAT=n
@graphics 130 80 0 0 10
r 0 0 0 130 80
*end blocksym
part 60 r 640 240 d
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R9
a 0 ap 9 0 15 0 hln 100 REFDES=R9
part 51 c 570 350 v
a 0 u 13 0 3 53 hln 100 VALUE=1n
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C5
a 0 ap 9 0 15 0 hln 100 REFDES=C5
part 50 c 590 200 v
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C4
a 0 ap 9 0 15 0 hln 100 REFDES=C4
part 59 r 590 320 d
a 0 u 13 0 27 45 hln 100 VALUE=1k
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R8
a 0 ap 9 0 15 0 hln 100 REFDES=R8
part 307 D1N5765 890 170 d
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=TO-46
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=D2
a 0 ap 9 0 23 -2 hln 100 REFDES=D2
a 0 sp 11 0 9 1 hln 100 PART=D1N5765
part 318 r 890 130 d
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R11
a 0 ap 9 0 15 0 hln 100 REFDES=R11
part 317 r 890 250 d
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R10
a 0 ap 9 0 15 0 hln 100 REFDES=R10
part 306 D1N5765 890 220 d
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=TO-46
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=D1
a 0 ap 9 0 23 -4 hln 100 REFDES=D1
a 0 sp 11 0 13 -1 hln 100 PART=D1N5765
part 292 opamp 800 190 h
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=U3
a 0 ap 9 0 14 0 hln 100 REFDES=U3
a 0 sp 11 0 32 58 hln 100 PART=opamp
part 1 titleblk 1024 640 h
a 1 s 13 0 180 60 hcn 100 PAGETITLE=
a 1 s 13 0 300 95 hrn 100 PAGENO=1
a 1 s 13 0 340 95 hrn 100 PAGECOUNT=1
a 1 s 13 0 350 10 hcn 100 PAGESIZE=A4
@conn
w 9
s 90 350 90 370 19
s 120 350 120 340 17
s 90 350 120 350 15
s 90 300 90 350 10
s 80 300 90 300 8
w 41
s 270 340 270 370 42
w 26
s 160 280 220 280 30
w 7
s 120 300 120 280 22
s 120 280 130 280 24
s 80 280 120 280 6
w 35
s 270 280 270 300 36
s 250 280 270 280 34
s 330 280 270 280 47
w 222
s 590 200 590 190 218
w 205
s 590 170 560 170 206
s 560 170 560 210 265
s 560 160 560 170 220
w 210
s 640 280 680 280 211
s 600 280 640 280 209
w 199
s 470 220 470 240 200
w 62
s 470 280 450 280 122
s 380 280 450 280 63
s 360 280 380 280 61
w 191
s 340 160 340 170 194
s 370 160 340 160 97
s 340 150 340 160 101
s 370 260 370 160 95
s 470 260 370 260 120
w 85
s 520 330 520 290 118
s 500 330 520 330 84
w 112
s 340 110 340 120 111
w 134
s 590 360 590 370 133
w 179
s 570 350 570 370 131
w 65
s 460 330 450 330 71
s 450 320 450 330 66
w 89
s 520 360 520 370 88
w 69
s 380 320 380 370 68
w 304
s 580 320 590 320 167
s 580 320 570 320 180
s 580 290 580 320 127
s 780 320 590 320 249
s 780 190 780 320 294
s 800 190 780 190 296
w 309
s 890 210 890 220 312
s 880 210 890 210 310
s 890 200 890 210 308
w 299
s 800 230 800 250 300
@junction
j 270 300
+ p 33 2
+ w 35
j 250 280
+ p 32 2
+ w 35
j 90 370
+ s 147
+ w 9
j 120 340
+ p 13 -
+ w 9
j 90 350
+ w 9
+ w 9
j 270 340
+ p 33 1
+ w 41
j 270 370
+ s 146
+ w 41
j 160 280
+ p 12 2
+ w 26
j 220 280
+ p 32 1
+ w 26
j 120 300
+ p 13 +
+ w 7
j 130 280
+ p 12 1
+ w 7
j 120 280
+ w 7
+ w 7
j 340 210
+ p 53 1
+ s 148
j 470 240
+ p 57 1
+ p 115 P10
j 430 240
+ p 57 2
+ s 114
j 550 290
+ p 115 P6
+ s 144
j 550 290
+ p 115 P6
+ s 145
j 640 240
+ p 60 1
+ s 212
j 550 290
+ s 144
+ s 145
j 330 280
+ p 49 1
+ w 35
j 270 280
+ w 35
+ w 35
j 590 200
+ p 50 1
+ w 222
j 590 190
+ s 208
+ w 222
j 590 170
+ p 50 2
+ w 205
j 560 210
+ p 115 P8
+ w 205
j 560 160
+ s 151
+ w 205
j 560 170
+ w 205
+ w 205
j 640 280
+ p 60 2
+ w 210
j 600 280
+ p 115 P9
+ w 210
j 470 240
+ p 57 1
+ w 199
j 470 240
+ p 115 P10
+ w 199
j 470 220
+ p 115 P11
+ w 199
j 450 280
+ p 56 2
+ w 62
j 470 280
+ p 115 P2
+ w 62
j 380 280
+ p 55 2
+ w 62
j 360 280
+ p 49 2
+ w 62
j 340 170
+ p 53 2
+ w 191
j 340 150
+ p 54 1
+ w 191
j 340 160
+ w 191
+ w 191
j 470 260
+ p 115 P1
+ w 191
j 520 330
+ p 83 1
+ w 85
j 520 290
+ p 115 P4
+ w 85
j 500 330
+ p 58 1
+ w 85
j 340 110
+ p 54 2
+ w 112
j 340 120
+ s 150
+ w 112
j 590 360
+ p 59 2
+ w 134
j 590 370
+ s 143
+ w 134
j 570 350
+ p 51 1
+ w 179
j 570 370
+ s 142
+ w 179
j 460 330
+ p 58 2
+ w 65
j 450 330
+ s 149
+ w 65
j 450 320
+ p 56 1
+ w 65
j 520 360
+ p 83 2
+ w 89
j 520 370
+ s 141
+ w 89
j 380 320
+ p 55 1
+ w 69
j 380 370
+ s 140
+ w 69
j 570 320
+ p 51 2
+ w 304
j 580 290
+ p 115 P7
+ w 304
j 590 320
+ p 59 1
+ w 304
j 580 320
+ w 304
+ w 304
j 800 190
+ p 292 +
+ w 304
j 890 220
+ p 306 1
+ w 309
j 880 210
+ p 292 OUT
+ w 309
j 890 200
+ p 307 2
+ w 309
j 890 210
+ w 309
+ w 309
j 890 170
+ p 318 2
+ p 307 1
j 890 130
+ s 316
+ p 318 1
j 890 250
+ p 317 1
+ p 306 2
j 890 290
+ s 315
+ p 317 2
j 800 230
+ p 292 -
+ w 299
@attributes
a 0 s 0:13 0 0 0 hln 100 PAGETITLE=
a 0 s 0:13 0 0 0 hln 100 PAGENO=1
a 0 s 0:13 0 0 0 hln 100 PAGESIZE=A4
a 0 s 0:13 0 0 0 hln 100 PAGECOUNT=1
@graphics
v 3 v 0 20 310
20 270
;
v 4 v 0 60 280
80 280
;
v 5 v 0 80 300
60 300
;
t 27 t 5 30 285 60 301 0 5
Micro
r 28 r 0 10 370 200 260
r 44 r 0 210 260 300 370
c 2 c 0 40 290 20
t 29 t 5 60 260 130 240 0 14 d_info:,,,,,,,,,,,,,9, 
Capteur Sonore
t 45 t 5 220 260 300 240 0 17 d_info:,,,,,,,,,,,,,9, 
Filtre Passe Haut
v 224 v 0 690 310
680 320
690 330
;
t 230 t 5 700 326 718 340 0 2
Vo
r 247 r 0 310 90 760 370
t 248 t 5 430 90 650 60 0 30 d_info:,,,,,,,,,,,,,15, 
Frequency to Voltage Convertor
t 229 t 5 690 306 760 330 0 14
Voltage Output
v 223 v 0 670 270
660 280
670 290
;
t 225 t 5 670 266 699 280 0 5
Pulse
t 226 t 5 670 276 685 290 0 2
to
t 228 t 5 670 286 703 300 0 6
Output
t 319 t 5 700 266 760 290 0 14
(Non Utilis�e)
*page 2 0 256 160 ma
@ports
port 363 GND_EARTH 100 390 h
port 377 GND_EARTH 900 150 u
port 378 GND_EARTH 900 310 h
@parts
part 340 c 140 300 h
a 0 sp 0 0 0 10 hlb 100 PART=c
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=CK05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=C8
a 0 ap 9 0 15 0 hln 100 REFDES=C8
part 341 vdc 130 320 h
a 1 u 13 0 -11 18 hcn 100 DC=9v
a 0 sp 0 0 22 37 hln 100 PART=vdc
a 0 a 0:13 0 0 0 hln 100 PKGREF=V4
a 1 ap 9 0 24 7 hcn 100 REFDES=V4
part 357 D1N5765 900 190 d
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=TO-46
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 sp 11 0 9 1 hln 100 PART=D1N5765
a 0 a 0:13 0 0 0 hln 100 PKGREF=D3
a 0 ap 9 0 23 -2 hln 100 REFDES=D3
part 358 r 900 150 d
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R21
a 0 ap 9 0 15 0 hln 100 REFDES=R21
part 359 r 900 270 d
a 0 sp 0 0 0 10 hlb 100 PART=r
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=RC05
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 a 0:13 0 0 0 hln 100 PKGREF=R22
a 0 ap 9 0 15 0 hln 100 REFDES=R22
part 360 D1N5765 900 240 d
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=TO-46
a 0 s 0:13 0 0 0 hln 100 GATE=
a 0 sp 11 0 13 -1 hln 100 PART=D1N5765
a 0 a 0:13 0 0 0 hln 100 PKGREF=D4
a 0 ap 9 0 23 -4 hln 100 REFDES=D4
part 361 opamp 810 210 h
a 0 s 0:13 0 0 0 hln 100 PKGTYPE=
a 0 sp 11 0 32 58 hln 100 PART=opamp
a 0 a 0:13 0 0 0 hln 100 PKGREF=U4
a 0 ap 9 0 14 0 hln 100 REFDES=U4
part 320 titleblk 1024 640 h
a 1 s 13 0 350 10 hcn 100 PAGESIZE=A4
a 1 s 13 0 180 60 hcn 100 PAGETITLE=
a 1 s 13 0 340 95 hrn 100 PAGECOUNT=2
a 1 s 13 0 300 95 hrn 100 PAGENO=2
@conn
w 380
s 100 370 100 390 379
s 130 370 130 360 381
s 100 370 130 370 383
s 100 320 100 370 385
s 90 320 100 320 387
w 394
s 130 320 130 300 393
s 130 300 140 300 395
s 90 300 130 300 397
w 467
s 900 230 900 240 466
s 890 230 900 230 468
s 900 220 900 230 470
w 473
s 810 250 810 270 472
w 392
s 170 300 230 300 391
w 475
s 790 340 600 340 460
s 790 210 790 340 462
s 810 210 790 210 464
@junction
j 900 190
+ p 358 2
+ p 357 1
j 900 270
+ p 360 2
+ p 359 1
j 900 150
+ s 377
+ p 358 1
j 900 310
+ s 378
+ p 359 2
j 100 390
+ s 363
+ w 380
j 130 360
+ p 341 -
+ w 380
j 100 370
+ w 380
+ w 380
j 170 300
+ p 340 2
+ w 392
j 130 320
+ p 341 +
+ w 394
j 140 300
+ p 340 1
+ w 394
j 130 300
+ w 394
+ w 394
j 810 210
+ p 361 +
+ w 475
j 900 240
+ p 360 1
+ w 467
j 890 230
+ p 361 OUT
+ w 467
j 900 220
+ p 357 2
+ w 467
j 900 230
+ w 467
+ w 467
j 810 250
+ p 361 -
+ w 473
@attributes
a 0 s 0:13 0 0 0 hln 100 PAGETITLE=
a 0 s 0:13 0 0 0 hln 100 PAGENO=2
a 0 s 0:13 0 0 0 hln 100 PAGESIZE=A4
a 0 s 0:13 0 0 0 hln 100 PAGECOUNT=2
@graphics
v 321 v 0 30 330
30 290
;
v 322 v 0 70 300
90 300
;
v 323 v 0 90 320
70 320
;
t 324 t 5 40 305 70 321 0 5
Micro
r 325 r 0 20 280 210 390
c 327 c 0 50 310 20
t 328 t 5 70 280 140 260 0 14 d_info:,,,,,,,,,,,,,9, 
Capteur Sonore
