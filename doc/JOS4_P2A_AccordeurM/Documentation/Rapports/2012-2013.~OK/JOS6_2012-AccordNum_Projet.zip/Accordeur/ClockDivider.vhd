----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date:    09:14:14 02/26/2013 
-- Design Name: 
-- Module Name:    ClockDivider - Behavioral 
-- Project Name: 
-- Target Devices: 
-- Tool versions: 
-- Description: 
--
-- Dependencies: 
--
-- Revision: 
-- Revision 0.01 - File Created
-- Additional Comments: 
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

---- Uncomment the following library declaration if instantiating
---- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity ClockDivider is
    Generic ( N : integer := 9;
	           Division : integer := 405);
    Port ( C : in  STD_LOGIC;
           SCLK : out  STD_LOGIC);
end ClockDivider;

architecture Behavioral of ClockDivider is
signal Q : STD_LOGIC_VECTOR ((N -1) downto 0) := (others => '0');

begin

process(C)

	begin
	if (C' event and C = '1') then
		if (Q < (CONV_STD_LOGIC_VECTOR((Division-1), N))) then
		    -- INCREMENTATION du COMPTEUR tant que Q < Division - 1
			 Q <= Q + '1';          
		else
		    -- REMISE A ZERO des que Q >= Division
			 Q <= (others => '0');	
		end if;
	end if;

end process;

-- L'HORLOGE de SORTIE est maintenue � '0' tant que Q < Division / 2
SCLK <= '0' when Q < (CONV_STD_LOGIC_VECTOR((Division/2), N)) else
        '1';

end Behavioral;
