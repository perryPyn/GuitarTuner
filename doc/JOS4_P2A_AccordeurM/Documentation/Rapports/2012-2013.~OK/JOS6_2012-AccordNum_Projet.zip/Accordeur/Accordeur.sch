VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "xbr"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL FreqVarDiv
        SIGNAL InitCompt
        SIGNAL ValidCompt
        SIGNAL QS(6:0)
        SIGNAL EtatZero
        SIGNAL SensCroiss
        SIGNAL FreqVar
        SIGNAL FreqRef
        SIGNAL Ecart(6:0)
        SIGNAL Signe
        SIGNAL XLXN_28
        PORT Input FreqVar
        PORT Input FreqRef
        PORT Output Ecart(6:0)
        PORT Output Signe
        BEGIN BLOCKDEF sequenceur
            TIMESTAMP 2013 5 28 13 32 6
            RECTANGLE N 64 -256 320 0 
            LINE N 64 -224 0 -224 
            LINE N 64 -128 0 -128 
            LINE N 64 -32 0 -32 
            LINE N 320 -224 384 -224 
            LINE N 320 -160 384 -160 
            LINE N 320 -96 384 -96 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF diviseur
            TIMESTAMP 2013 5 28 14 1 14
            RECTANGLE N 64 -64 320 0 
            LINE N 64 -32 0 -32 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF Compteur
            TIMESTAMP 2013 5 21 12 37 41
            RECTANGLE N 64 -256 320 0 
            LINE N 64 -224 0 -224 
            LINE N 64 -160 0 -160 
            LINE N 64 -96 0 -96 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -44 384 -20 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF registre
            TIMESTAMP 2013 1 15 13 47 22
            LINE N 64 32 0 32 
            LINE N 64 -160 0 -160 
            LINE N 64 -96 0 -96 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            LINE N 368 -224 432 -224 
            RECTANGLE N 368 -44 432 -20 
            LINE N 368 -32 432 -32 
            RECTANGLE N 64 -256 368 64 
        END BLOCKDEF
        BEGIN BLOCKDEF etat_0
            TIMESTAMP 2013 1 15 14 17 11
            RECTANGLE N 64 -128 320 0 
            RECTANGLE N 0 -44 64 -20 
            LINE N 64 -32 0 -32 
            LINE N 320 -96 384 -96 
        END BLOCKDEF
        BEGIN BLOCK XLXI_2 diviseur
            PIN FreqVar FreqVar
            PIN Mesure FreqVarDiv
        END BLOCK
        BEGIN BLOCK XLXI_1 sequenceur
            PIN Mesure FreqVarDiv
            PIN Etat_0 EtatZero
            PIN FreqRef FreqRef
            PIN InitCompt InitCompt
            PIN ValidCompt ValidCompt
            PIN SensCroiss SensCroiss
            PIN ChargReg XLXN_28
        END BLOCK
        BEGIN BLOCK XLXI_8 Compteur
            PIN clk FreqRef
            PIN InitCompt InitCompt
            PIN ValidCompt ValidCompt
            PIN SensCroiss SensCroiss
            PIN qs(6:0) QS(6:0)
        END BLOCK
        BEGIN BLOCK XLXI_9 registre
            PIN FreqRef FreqRef
            PIN ChargReg XLXN_28
            PIN SensCroiss SensCroiss
            PIN Reg(6:0) QS(6:0)
            PIN SensCroiss_out Signe
            PIN Reg_out(6:0) Ecart(6:0)
        END BLOCK
        BEGIN BLOCK XLXI_10 etat_0
            PIN e(6:0) QS(6:0)
            PIN Etat_0 EtatZero
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 2688 1900
        ATTR LengthUnitName "CM"
        ATTR GridsPerUnit "4"
        BEGIN INSTANCE XLXI_2 256 800 R0
        END INSTANCE
        BEGIN INSTANCE XLXI_1 784 992 R0
        END INSTANCE
        BEGIN BRANCH FreqVarDiv
            WIRE 640 768 704 768
            WIRE 704 768 784 768
            BEGIN DISPLAY 696 764 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH InitCompt
            WIRE 1168 768 1552 768
            WIRE 1552 768 2016 768
            BEGIN DISPLAY 1544 764 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH ValidCompt
            WIRE 1168 832 1552 832
            WIRE 1552 832 2016 832
            BEGIN DISPLAY 1544 828 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH QS(6:0)
            WIRE 1728 1008 1936 1008
            WIRE 1936 1008 2416 1008
            WIRE 1936 1008 1936 1344
            WIRE 1936 1344 1952 1344
            WIRE 2400 896 2416 896
            WIRE 2416 896 2416 1008
            BEGIN DISPLAY 1928 1004 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH EtatZero
            WIRE 672 864 672 1072
            WIRE 672 1072 1344 1072
            WIRE 672 864 704 864
            WIRE 704 864 784 864
            BEGIN DISPLAY 696 860 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_8 2016 928 R0
        END INSTANCE
        BEGIN INSTANCE XLXI_9 1952 1376 R0
        END INSTANCE
        BEGIN BRANCH SensCroiss
            WIRE 1168 896 1552 896
            WIRE 1552 896 1824 896
            WIRE 1824 896 2016 896
            WIRE 1824 896 1824 1280
            WIRE 1824 1280 1952 1280
            BEGIN DISPLAY 1544 892 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH FreqVar
            WIRE 224 768 256 768
        END BRANCH
        BEGIN BRANCH FreqRef
            WIRE 208 960 768 960
            WIRE 768 960 784 960
        END BRANCH
        BEGIN BRANCH FreqRef
            WIRE 1952 704 2000 704
            WIRE 2000 704 2016 704
            BEGIN DISPLAY 1944 700 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH FreqRef
            WIRE 1872 1408 1936 1408
            WIRE 1936 1408 1952 1408
            BEGIN DISPLAY 1864 1404 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Ecart(6:0)
            WIRE 2384 1344 2416 1344
        END BRANCH
        BEGIN BRANCH Signe
            WIRE 2384 1152 2416 1152
        END BRANCH
        BEGIN BRANCH XLXN_28
            WIRE 1168 960 1248 960
            WIRE 1248 960 1248 1216
            WIRE 1248 1216 1952 1216
        END BRANCH
        BEGIN INSTANCE XLXI_10 1728 976 R180
        END INSTANCE
        IOMARKER 224 768 FreqVar R180 28
        IOMARKER 2416 1344 Ecart(6:0) R0 28
        IOMARKER 2416 1152 Signe R0 28
        IOMARKER 208 960 FreqRef R180 28
    END SHEET
END SCHEMATIC
