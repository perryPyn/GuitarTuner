--------------------------------------------------------------------------------
-- Copyright (c) 1995-2007 Xilinx, Inc.  All rights reserved.
--------------------------------------------------------------------------------
--   ____  ____ 
--  /   /\/   / 
-- /___/  \  /    Vendor: Xilinx 
-- \   \   \/     Version : 9.2.04i
--  \   \         Application : sch2vhdl
--  /   /         Filename : bidon.vhf
-- /___/   /\     Timestamp : 05/21/2013 15:40:15
-- \   \  /  \ 
--  \___\/\___\ 
--
--Command: C:\PROGRAMS\Xilinx92i\bin\nt\sch2vhdl.exe -intstyle ise -family xbr -flat -suppress -w U:/Windows/Documents/Accordeur/bidon.sch bidon.vhf
--Design Name: bidon
--Device: xbr
--Purpose:
--    This vhdl netlist is translated from an ECS schematic. It can be 
--    synthesis and simulted, but it should not be modified. 
--

library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
library UNISIM;
use UNISIM.Vcomponents.ALL;

entity bidon is
   port ( e : in    std_logic; 
          s : out   std_logic);
end bidon;

architecture BEHAVIORAL of bidon is
   attribute BOX_TYPE   : string ;
   component INV
      port ( I : in    std_logic; 
             O : out   std_logic);
   end component;
   attribute BOX_TYPE of INV : component is "BLACK_BOX";
   
begin
   XLXI_1 : INV
      port map (I=>e,
                O=>s);
   
end BEHAVIORAL;


