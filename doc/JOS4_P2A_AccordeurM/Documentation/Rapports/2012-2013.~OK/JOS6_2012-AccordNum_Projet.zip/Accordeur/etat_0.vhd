----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date:    15:46:03 10/16/2012 
-- Design Name: 
-- Module Name:    etat_0 - Behavioral 
-- Project Name: 
-- Target Devices: 
-- Tool versions: 
-- Description: 
--
-- Dependencies: 
--
-- Revision: 
-- Revision 0.01 - File Created
-- Additional Comments: 
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

---- Uncomment the following library declaration if instantiating
---- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity etat_0 is
    Port ( e : in  STD_LOGIC_VECTOR(6 downto 0);
			  Etat_0 : out STD_LOGIC := '0');
end etat_0;

architecture Behavioral of etat_0 is

begin
	        
		etat_0 <= NOT e(6) and NOT e(5) and NOT e(4) and NOT e(3) and NOT e(2) and NOT e(1) and NOT e(0);
		
	

end Behavioral;

