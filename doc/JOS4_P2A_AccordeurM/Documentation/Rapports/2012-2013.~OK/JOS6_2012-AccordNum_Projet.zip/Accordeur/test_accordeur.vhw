--------------------------------------------------------------------------------
-- Copyright (c) 1995-2007 Xilinx, Inc.
-- All Right Reserved.
--------------------------------------------------------------------------------
--   ____  ____ 
--  /   /\/   / 
-- /___/  \  /    Vendor: Xilinx 
-- \   \   \/     Version : 9.2.04i
--  \   \         Application : ISE
--  /   /         Filename : test_accordeur.vhw
-- /___/   /\     Timestamp : Tue May 28 16:05:47 2013
-- \   \  /  \ 
--  \___\/\___\ 
--
--Command: 
--Design Name: test_accordeur
--Device: Xilinx
--

library UNISIM;
use UNISIM.Vcomponents.ALL;
library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE STD.TEXTIO.ALL;

ENTITY test_accordeur IS
END test_accordeur;

ARCHITECTURE testbench_arch OF test_accordeur IS
    FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";

    COMPONENT Demo_Accordeur
        PORT (
            e_clk : In std_logic;
            e_freqvar : In std_logic;
            s_ecart : Out std_logic_vector (6 DownTo 0);
            s_signe : Out std_logic
        );
    END COMPONENT;

    SIGNAL e_clk : std_logic := '0';
    SIGNAL e_freqvar : std_logic := '0';
    SIGNAL s_ecart : std_logic_vector (6 DownTo 0) := "0000000";
    SIGNAL s_signe : std_logic := '0';

    constant PERIOD_e_clk : time := 200 ns;
    constant DUTY_CYCLE_e_clk : real := 0.5;
    constant OFFSET_e_clk : time := 100 ns;
    constant PERIOD_e_freqvar : time := 214 ns;
    constant DUTY_CYCLE_e_freqvar : real := 0.5;
    constant OFFSET_e_freqvar : time := 100 ns;

    BEGIN
        UUT : Demo_Accordeur
        PORT MAP (
            e_clk => e_clk,
            e_freqvar => e_freqvar,
            s_ecart => s_ecart,
            s_signe => s_signe
        );

        PROCESS    -- clock process for e_clk
        BEGIN
            WAIT for OFFSET_e_clk;
            CLOCK_LOOP : LOOP
                e_clk <= '0';
                WAIT FOR (PERIOD_e_clk - (PERIOD_e_clk * DUTY_CYCLE_e_clk));
                e_clk <= '1';
                WAIT FOR (PERIOD_e_clk * DUTY_CYCLE_e_clk);
            END LOOP CLOCK_LOOP;
        END PROCESS;

        PROCESS    -- clock process for e_freqvar
        BEGIN
            WAIT for OFFSET_e_freqvar;
            CLOCK_LOOP : LOOP
                e_freqvar <= '0';
                WAIT FOR (PERIOD_e_freqvar - (PERIOD_e_freqvar * DUTY_CYCLE_e_freqvar));
                e_freqvar <= '1';
                WAIT FOR (PERIOD_e_freqvar * DUTY_CYCLE_e_freqvar);
            END LOOP CLOCK_LOOP;
        END PROCESS;

        PROCESS    -- Process for e_clk
            BEGIN
                WAIT FOR 200214 ns;

            END PROCESS;

    END testbench_arch;

