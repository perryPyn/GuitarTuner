////////////////////////////////////////////////////////////////////////////////
//   ____  ____   
//  /   /\/   /  
// /___/  \  /   
// \   \   \/  
//  \   \        Copyright (c) 2003-2004 Xilinx, Inc.
//  /   /        All Right Reserved. 
// /---/   /\     
// \   \  /  \  
//  \___\/\___\
////////////////////////////////////////////////////////////////////////////////

#ifndef H_Work_clockdivider_behavioral_H
#define H_Work_clockdivider_behavioral_H
#ifdef __MINGW32__
#include "xsimMinGW.h"
#else
#include "xsim.h"
#endif


class Work_clockdivider_behavioral: public HSim__s6 {
public:

    HSim__s4 PE[2];
    HSim__s1 SE[2];

  char *t2;
    HSim__s1 SA[1];
  char t3;
HSimConstraints *c4;
  char *t5;
    Work_clockdivider_behavioral(const char * name);
    ~Work_clockdivider_behavioral();
    void constructObject();
    void constructPorts();
    void reset();
    void architectureInstantiate(HSimConfigDecl* cfg);
    virtual void vhdlArchImplement();
};



HSim__s6 *createWork_clockdivider_behavioral(const char *name);

#endif
