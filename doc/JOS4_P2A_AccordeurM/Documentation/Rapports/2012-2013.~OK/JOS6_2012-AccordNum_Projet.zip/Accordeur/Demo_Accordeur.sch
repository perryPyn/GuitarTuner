VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "xbr"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL e_freqvar
        SIGNAL s_signe
        SIGNAL s_ecart(6:0)
        SIGNAL e_clk
        PORT Input e_freqvar
        PORT Output s_signe
        PORT Output s_ecart(6:0)
        PORT Input e_clk
        BEGIN BLOCKDEF Accordeur
            TIMESTAMP 2013 5 28 14 1 36
            RECTANGLE N 64 -128 320 0 
            LINE N 64 -96 0 -96 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -108 384 -84 
            LINE N 320 -96 384 -96 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 Accordeur
            PIN FreqVar e_freqvar
            PIN FreqRef e_clk
            PIN Ecart(6:0) s_ecart(6:0)
            PIN Signe s_signe
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 1900 1344
        ATTR LengthUnitName "CM"
        ATTR GridsPerUnit "4"
        BEGIN INSTANCE XLXI_1 1040 752 R0
        END INSTANCE
        BEGIN BRANCH e_freqvar
            WIRE 320 656 1040 656
        END BRANCH
        BEGIN BRANCH s_signe
            WIRE 1424 720 1584 720
        END BRANCH
        IOMARKER 320 656 e_freqvar R180 28
        BEGIN BRANCH s_ecart(6:0)
            WIRE 1424 656 1584 656
        END BRANCH
        IOMARKER 1584 656 s_ecart(6:0) R0 28
        IOMARKER 1584 720 s_signe R0 28
        IOMARKER 272 960 e_clk R180 28
        BEGIN BRANCH e_clk
            WIRE 272 960 368 960
            WIRE 368 960 368 1008
            WIRE 368 1008 480 1008
            WIRE 480 1008 864 1008
            WIRE 864 1008 944 1008
            WIRE 944 720 944 1008
            WIRE 944 720 1040 720
        END BRANCH
    END SHEET
END SCHEMATIC
