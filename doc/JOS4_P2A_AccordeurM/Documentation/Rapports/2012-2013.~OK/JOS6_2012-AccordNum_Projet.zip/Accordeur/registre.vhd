----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date:    16:51:55 10/16/2012 
-- Design Name: 
-- Module Name:    registre - Behavioral 
-- Project Name: 
-- Target Devices: 
-- Tool versions: 
-- Description: 
--
-- Dependencies: 
--
-- Revision: 
-- Revision 0.01 - File Created
-- Additional Comments: 
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

---- Uncomment the following library declaration if instantiating
---- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity registre is
    Port ( FreqRef : in  STD_LOGIC;
           ChargReg : in  STD_LOGIC;
           SensCroiss : in  STD_LOGIC;
           Reg : in  STD_LOGIC_VECTOR (6 downto 0);
           Reg_out : out  STD_LOGIC_VECTOR (6 downto 0):="0000000";
           SensCroiss_out : out STD_LOGIC:='0');
end registre;

architecture Behavioral of registre is

begin
  PROCESS(FreqRef) BEGIN
    IF FreqRef'event and FreqRef='1' and ChargReg='1' THEN
      Reg_out <= Reg;
		SensCroiss_out <= SensCroiss;		
	 END IF;
  END PROCESS;
end Behavioral;

