----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date:    14:57:48 10/16/2012 
-- Design Name: 
-- Module Name:    Cmpt8 - Behavioral 
-- Project Name: 
-- Target Devices: 
-- Tool versions: 
-- Description: 
--
-- Dependencies: 
--
-- Revision: 
-- Revision 0.01 - File Created
-- Additional Comments: 
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

---- Uncomment the following library declaration if instantiating
---- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Cmpt8 is
    Port ( CLK : in  STD_LOGIC;
           InitCompt : in  STD_LOGIC;
           ValidCompt : in  STD_LOGIC;
           SensCroiss : in  STD_LOGIC;
           CR : out  STD_LOGIC_VECTOR (7 downto 0);
           Etat_0 : out  STD_LOGIC);
end Cmpt8;

architecture Behavioral of Cmpt8 is

begin


end Behavioral;

