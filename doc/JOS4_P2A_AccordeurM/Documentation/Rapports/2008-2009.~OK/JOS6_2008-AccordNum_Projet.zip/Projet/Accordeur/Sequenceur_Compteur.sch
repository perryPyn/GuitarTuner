VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "xbr"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL XLXN_1
        SIGNAL XLXN_2
        SIGNAL ChargerR
        SIGNAL Freq_ref
        SIGNAL Mesure
        SIGNAL Etat(7:0)
        SIGNAL Signe
        SIGNAL XLXN_4
        PORT Output ChargerR
        PORT Input Freq_ref
        PORT Input Mesure
        PORT Output Etat(7:0)
        PORT Output Signe
        BEGIN BLOCKDEF Sequenceur
            TIMESTAMP 2009 4 3 17 20 46
            RECTANGLE N 64 -256 320 0 
            LINE N 64 -224 0 -224 
            LINE N 64 -32 0 -32 
            LINE N 320 -224 384 -224 
            LINE N 320 -160 384 -160 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF Compteur
            TIMESTAMP 2009 4 5 11 0 2
            LINE N 320 80 384 80 
            RECTANGLE N 320 -300 384 -276 
            LINE N 320 -288 384 -288 
            LINE N 68 -288 4 -288 
            LINE N 64 -240 0 -240 
            LINE N 64 -16 0 -16 
            RECTANGLE N 64 -320 320 96 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 Sequenceur
            PIN Mesure Mesure
            PIN Clk Freq_ref
            PIN ChargerR ChargerR
            PIN InitC XLXN_1
            PIN ValidC XLXN_2
        END BLOCK
        BEGIN BLOCK XLXI_3 Compteur
            PIN InitC XLXN_1
            PIN ValidC XLXN_2
            PIN Clk Freq_ref
            PIN Etat(7:0) Etat(7:0)
            PIN Signe Signe
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 1900 1344
        ATTR LengthUnitName "CM"
        ATTR GridsPerUnit "4"
        BEGIN INSTANCE XLXI_1 448 704 R0
        END INSTANCE
        BEGIN BRANCH XLXN_1
            WIRE 832 480 1040 480
        END BRANCH
        BEGIN BRANCH XLXN_2
            WIRE 832 544 928 544
            WIRE 928 528 928 544
            WIRE 928 528 1040 528
        END BRANCH
        BEGIN BRANCH ChargerR
            WIRE 832 672 864 672
        END BRANCH
        IOMARKER 864 672 ChargerR R0 28
        BEGIN BRANCH Freq_ref
            WIRE 416 672 448 672
        END BRANCH
        BEGIN BRANCH Freq_ref
            WIRE 992 752 1024 752
            WIRE 1024 752 1040 752
            BEGIN DISPLAY 992 752 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Mesure
            WIRE 416 480 448 480
        END BRANCH
        IOMARKER 416 480 Mesure R180 28
        BEGIN BRANCH Etat(7:0)
            WIRE 1424 480 1456 480
        END BRANCH
        IOMARKER 1456 480 Etat(7:0) R0 28
        IOMARKER 416 672 Freq_ref R180 28
        BEGIN INSTANCE XLXI_3 1040 768 R0
        END INSTANCE
        BEGIN BRANCH Signe
            WIRE 1424 848 1440 848
        END BRANCH
        IOMARKER 1440 848 Signe R0 28
    END SHEET
END SCHEMATIC
