VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "xbr"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL ZERO
        SIGNAL Clk
        SIGNAL Etat(7:0)
        SIGNAL ChargerR
        SIGNAL Etat_mem(7:0)
        SIGNAL Signe
        SIGNAL Signe_mem
        PORT Input Clk
        PORT Input Etat(7:0)
        PORT Input ChargerR
        PORT Output Etat_mem(7:0)
        PORT Input Signe
        PORT Output Signe_mem
        BEGIN BLOCKDEF fd8ce
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -128 64 -128 
            LINE N 0 -192 64 -192 
            LINE N 0 -32 64 -32 
            LINE N 0 -256 64 -256 
            LINE N 384 -256 320 -256 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            RECTANGLE N 320 -268 384 -244 
            RECTANGLE N 0 -268 64 -244 
            RECTANGLE N 64 -320 320 -64 
        END BLOCKDEF
        BEGIN BLOCKDEF gnd
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 -128 64 -96 
            LINE N 64 -64 64 -80 
            LINE N 88 -64 40 -64 
            LINE N 68 -32 60 -32 
            LINE N 76 -48 52 -48 
            LINE N 64 -64 64 -96 
        END BLOCKDEF
        BEGIN BLOCKDEF fdce
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -128 64 -128 
            LINE N 0 -192 64 -192 
            LINE N 0 -32 64 -32 
            LINE N 0 -256 64 -256 
            LINE N 384 -256 320 -256 
            LINE N 64 -112 80 -128 
            LINE N 80 -128 64 -144 
            LINE N 192 -64 192 -32 
            LINE N 192 -32 64 -32 
            RECTANGLE N 64 -320 320 -64 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 fd8ce
            PIN C Clk
            PIN CE ChargerR
            PIN CLR ZERO
            PIN D(7:0) Etat(7:0)
            PIN Q(7:0) Etat_mem(7:0)
        END BLOCK
        BEGIN BLOCK XLXI_3 gnd
            PIN G ZERO
        END BLOCK
        BEGIN BLOCK XLXI_14 fdce
            PIN C Clk
            PIN CE ChargerR
            PIN CLR ZERO
            PIN D Signe
            PIN Q Signe_mem
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 1900 1344
        ATTR LengthUnitName "CM"
        ATTR GridsPerUnit "4"
        INSTANCE XLXI_1 720 832 R0
        INSTANCE XLXI_3 272 464 R0
        BEGIN BRANCH ZERO
            WIRE 336 320 336 336
            BEGIN DISPLAY 336 320 ATTR Name
                ALIGNMENT SOFT-VLEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH ZERO
            WIRE 704 800 720 800
            BEGIN DISPLAY 704 800 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Clk
            WIRE 688 704 720 704
        END BRANCH
        IOMARKER 688 704 Clk R180 28
        BEGIN BRANCH Etat(7:0)
            WIRE 704 576 720 576
        END BRANCH
        BEGIN BRANCH ChargerR
            WIRE 688 640 720 640
        END BRANCH
        IOMARKER 688 640 ChargerR R180 28
        BEGIN BRANCH Etat_mem(7:0)
            WIRE 1104 576 1136 576
        END BRANCH
        IOMARKER 1136 576 Etat_mem(7:0) R0 28
        IOMARKER 704 576 Etat(7:0) R180 28
        INSTANCE XLXI_14 736 1152 R0
        BEGIN BRANCH Clk
            WIRE 720 1024 736 1024
            BEGIN DISPLAY 720 1024 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH ZERO
            WIRE 720 1120 736 1120
            BEGIN DISPLAY 720 1120 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Signe
            WIRE 720 896 736 896
        END BRANCH
        BEGIN BRANCH ChargerR
            WIRE 720 960 736 960
            BEGIN DISPLAY 720 960 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Signe_mem
            WIRE 1120 896 1136 896
        END BRANCH
        IOMARKER 720 896 Signe R180 28
        IOMARKER 1136 896 Signe_mem R0 28
    END SHEET
END SCHEMATIC
