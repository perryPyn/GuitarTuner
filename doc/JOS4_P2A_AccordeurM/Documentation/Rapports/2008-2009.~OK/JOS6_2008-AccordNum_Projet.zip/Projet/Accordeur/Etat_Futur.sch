VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "xbr"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL Mesure
        SIGNAL Q
        SIGNAL Jojo
        SIGNAL XLXN_4
        SIGNAL D
        PORT Input Mesure
        PORT Input Q
        PORT Output D
        BEGIN BLOCKDEF and2
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 192 -96 
            ARC N 96 -144 192 -48 144 -48 144 -144 
            LINE N 144 -48 64 -48 
            LINE N 64 -144 144 -144 
            LINE N 64 -48 64 -144 
        END BLOCKDEF
        BEGIN BLOCKDEF and2b1
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 -48 64 -144 
            LINE N 64 -144 144 -144 
            LINE N 144 -48 64 -48 
            ARC N 96 -144 192 -48 144 -48 144 -144 
            LINE N 256 -96 192 -96 
            LINE N 0 -128 64 -128 
            LINE N 0 -64 40 -64 
            CIRCLE N 40 -76 64 -52 
        END BLOCKDEF
        BEGIN BLOCKDEF or2
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 192 -96 
            ARC N 28 -224 204 -48 112 -48 192 -96 
            ARC N -40 -152 72 -40 48 -48 48 -144 
            LINE N 112 -144 48 -144 
            ARC N 28 -144 204 32 192 -96 112 -144 
            LINE N 112 -48 48 -48 
        END BLOCKDEF
        BEGIN BLOCK XLXI_11 and2
            PIN I0 Q
            PIN I1 Mesure
            PIN O Jojo
        END BLOCK
        BEGIN BLOCK XLXI_12 and2b1
            PIN I0 Q
            PIN I1 Mesure
            PIN O XLXN_4
        END BLOCK
        BEGIN BLOCK XLXI_13 or2
            PIN I0 XLXN_4
            PIN I1 Jojo
            PIN O D
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 1900 1344
        ATTR LengthUnitName "CM"
        ATTR GridsPerUnit "4"
        BEGIN BRANCH Mesure
            WIRE 544 368 576 368
        END BRANCH
        IOMARKER 544 368 Mesure R180 28
        BEGIN BRANCH Q
            WIRE 544 432 576 432
        END BRANCH
        IOMARKER 544 432 Q R180 28
        BEGIN BRANCH Jojo
            WIRE 832 400 864 400
            WIRE 864 400 864 448
            WIRE 864 448 880 448
            WIRE 880 448 944 448
            BEGIN DISPLAY 880 448 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_11 576 496 R0
        INSTANCE XLXI_12 624 672 R0
        INSTANCE XLXI_13 944 576 R0
        BEGIN BRANCH Mesure
            WIRE 576 544 624 544
            BEGIN DISPLAY 576 544 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Q
            WIRE 592 608 624 608
            BEGIN DISPLAY 592 608 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_4
            WIRE 880 576 912 576
            WIRE 912 512 912 576
            WIRE 912 512 944 512
        END BRANCH
        BEGIN BRANCH D
            WIRE 1200 480 1232 480
        END BRANCH
        IOMARKER 1232 480 D R0 28
    END SHEET
END SCHEMATIC
