% 1) se fixer un temps de regard : T
% 2) se fixer une taille de FFT : taille
% 3) construire une somme de sinus : x
% 4) calculer la FFT : X
% 5) trouver le maximum : mAx
% 6) en d�duire la f�quence de l'harmonique fondamentale : f0
clear all
close all
% 1)
T = 0.239;
%-------------------------------------------------------------

% 2)
taille = 1024;
%-------------------------------------------------------------

Fe = taille/T;
t = 0 : T/taille : T-T/taille;
f1 = 300;

% 3)
x = sin(2*pi*f1*t) + 1/3*sin(2*pi*2*f1*t) + 1/12*sin(2*pi*3*f1*t) ;
x = x + 1/4,5*sin(2*pi*4*f1*t) + 1/6*sin(2*pi*5*f1*t) + 1/15*sin(2*pi*6*f1*t); 
%-------------------------------------------------------------

f = 0 : 1/T : (taille-1)/T;

% 4)
X = abs(fft(x,taille));
%-------------------------------------------------------------

% 5)
[mAx,ind] = max(X);
%-------------------------------------------------------------

% 6)
f0 = (ind-1)/T
%-------------------------------------------------------------

subplot(2,1,1);
plot(t,x)
subplot(2,1,2);
semilogx(f,X)