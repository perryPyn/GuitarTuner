% spectre d'un fichier wave
function [] = spectre(nomSon, Fe)

t = 0:1/Fe:1;
re = wavread(nomSon);
%re = sin(2*pi*440*t);
wavplay(re,Fe);

FFT_t = 2048*32;
f = (0:FFT_t-1)*Fe/FFT_t;

re_fft = abs(fft(re,FFT_t));

semilogx(f,re_fft);
%plot(re)