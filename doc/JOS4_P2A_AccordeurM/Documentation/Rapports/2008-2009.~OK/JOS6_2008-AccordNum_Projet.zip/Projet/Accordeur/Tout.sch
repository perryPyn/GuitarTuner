VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "xbr"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL XLXN_1
        SIGNAL Freq_guit
        SIGNAL ChargerR
        SIGNAL Etat(7:0)
        SIGNAL Freq_ref
        SIGNAL Etat_mem(7:0)
        SIGNAL Signe_mem
        SIGNAL XLXN_5
        SIGNAL Affich(7:0)
        SIGNAL Affich8
        PORT Input Freq_guit
        PORT Input Freq_ref
        PORT Output Affich(7:0)
        PORT Output Affich8
        BEGIN BLOCKDEF Diviseur
            TIMESTAMP 2009 4 4 17 17 38
            RECTANGLE N 64 -128 320 0 
            LINE N 64 -96 0 -96 
            LINE N 320 -96 384 -96 
        END BLOCKDEF
        BEGIN BLOCKDEF Sequenceur_Compteur
            TIMESTAMP 2009 4 5 11 0 28
            LINE N 320 160 384 160 
            LINE N 64 32 0 32 
            LINE N 64 -32 0 -32 
            LINE N 320 -96 384 -96 
            RECTANGLE N 320 -44 384 -20 
            LINE N 320 -32 384 -32 
            RECTANGLE N 64 -128 320 192 
        END BLOCKDEF
        BEGIN BLOCKDEF Recuperation_etat
            TIMESTAMP 2009 4 5 10 52 20
            LINE N 64 96 0 96 
            LINE N 320 96 384 96 
            LINE N 64 32 0 32 
            LINE N 64 -160 0 -160 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -96 0 -96 
            RECTANGLE N 320 -172 384 -148 
            LINE N 320 -160 384 -160 
            RECTANGLE N 64 -192 320 128 
        END BLOCKDEF
        BEGIN BLOCKDEF Afficheur
            TIMESTAMP 2009 4 28 12 33 53
            RECTANGLE N 64 -128 320 0 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -96 0 -96 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -108 384 -84 
            LINE N 320 -96 384 -96 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 Diviseur
            PIN Freq_in Freq_guit
            PIN Mesure XLXN_1
        END BLOCK
        BEGIN BLOCK XLXI_2 Sequenceur_Compteur
            PIN Freq_ref Freq_ref
            PIN Mesure XLXN_1
            PIN ChargerR ChargerR
            PIN Etat(7:0) Etat(7:0)
            PIN Signe XLXN_5
        END BLOCK
        BEGIN BLOCK XLXI_5 Recuperation_etat
            PIN Clk Freq_ref
            PIN Etat(7:0) Etat(7:0)
            PIN ChargerR ChargerR
            PIN Etat_mem(7:0) Etat_mem(7:0)
            PIN Signe XLXN_5
            PIN Signe_mem Signe_mem
        END BLOCK
        BEGIN BLOCK XLXI_6 Afficheur
            PIN Etat_mem(7:0) Etat_mem(7:0)
            PIN Signe_mem Signe_mem
            PIN Affich(7:0) Affich(7:0)
            PIN Affich8 Affich8
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 1900 1344
        ATTR LengthUnitName "CM"
        ATTR GridsPerUnit "4"
        BEGIN BRANCH XLXN_1
            WIRE 576 432 720 432
        END BRANCH
        BEGIN INSTANCE XLXI_1 192 528 R0
        END INSTANCE
        BEGIN BRANCH Freq_guit
            WIRE 160 432 192 432
        END BRANCH
        IOMARKER 160 432 Freq_guit R180 28
        BEGIN INSTANCE XLXI_2 720 464 R0
        END INSTANCE
        BEGIN BRANCH ChargerR
            WIRE 1104 368 1120 368
            WIRE 1120 368 1264 368
        END BRANCH
        BEGIN BRANCH Etat(7:0)
            WIRE 1104 432 1120 432
            WIRE 1120 432 1264 432
        END BRANCH
        BEGIN BRANCH Freq_ref
            WIRE 688 496 720 496
        END BRANCH
        IOMARKER 688 496 Freq_ref R180 28
        BEGIN INSTANCE XLXI_5 1264 528 R0
        END INSTANCE
        BEGIN BRANCH Freq_ref
            WIRE 1248 560 1264 560
            BEGIN DISPLAY 1248 560 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Etat_mem(7:0)
            WIRE 1648 368 1664 368
            WIRE 1664 368 1680 368
            BEGIN DISPLAY 1680 368 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Signe_mem
            WIRE 1648 624 1664 624
            WIRE 1664 624 1680 624
            BEGIN DISPLAY 1680 624 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_5
            WIRE 1104 624 1264 624
        END BRANCH
        BEGIN INSTANCE XLXI_6 608 1056 R0
        END INSTANCE
        BEGIN BRANCH Etat_mem(7:0)
            WIRE 592 960 608 960
            BEGIN DISPLAY 592 960 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Signe_mem
            WIRE 592 1024 608 1024
            BEGIN DISPLAY 592 1024 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Affich(7:0)
            WIRE 992 960 1008 960
        END BRANCH
        BEGIN BRANCH Affich8
            WIRE 992 1024 1008 1024
        END BRANCH
        IOMARKER 1008 960 Affich(7:0) R0 28
        IOMARKER 1008 1024 Affich8 R0 28
    END SHEET
END SCHEMATIC
