function [valeur] = test_son(son, FFT_taille, Fe)

Note = wavread(son);
Note2 = Note(1:10:length(Note));

f = 0:Fe/FFT_taille:Fe-Fe/FFT_taille;
Note2_fft = abs(fft(Note2,FFT_taille));

semilogx(f,Note2_fft)

[maxX,indice] = max(Note2_fft);
valeur = (indice/FFT_taille)*Fe