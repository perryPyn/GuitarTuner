VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "xbr"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL Clk
        SIGNAL D0
        SIGNAL Q1
        SIGNAL D1
        SIGNAL Q0
        PORT Input Clk
        PORT Input D0
        PORT Output Q1
        PORT Input D1
        PORT Output Q0
        BEGIN BLOCKDEF fd
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 -112 80 -128 
            LINE N 80 -128 64 -144 
            LINE N 384 -256 320 -256 
            LINE N 0 -256 64 -256 
            LINE N 0 -128 64 -128 
            RECTANGLE N 64 -320 320 -64 
        END BLOCKDEF
        BEGIN BLOCK XLXI_4 fd
            PIN C Clk
            PIN D D0
            PIN Q Q0
        END BLOCK
        BEGIN BLOCK XLXI_5 fd
            PIN C Clk
            PIN D D1
            PIN Q Q1
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 1900 1344
        ATTR LengthUnitName "CM"
        ATTR GridsPerUnit "4"
        INSTANCE XLXI_4 304 704 R0
        BEGIN BRANCH Clk
            WIRE 288 576 304 576
        END BRANCH
        BEGIN BRANCH D0
            WIRE 272 448 304 448
        END BRANCH
        IOMARKER 272 448 D0 R180 28
        BEGIN BRANCH Clk
            WIRE 864 768 880 768
            BEGIN DISPLAY 864 768 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Q1
            WIRE 1264 640 1296 640
        END BRANCH
        INSTANCE XLXI_5 880 896 R0
        BEGIN BRANCH D1
            WIRE 848 640 880 640
        END BRANCH
        IOMARKER 1296 640 Q1 R0 28
        IOMARKER 848 640 D1 R180 28
        BEGIN BRANCH Q0
            WIRE 688 448 720 448
        END BRANCH
        IOMARKER 720 448 Q0 R0 28
        IOMARKER 288 576 Clk R180 28
    END SHEET
END SCHEMATIC
