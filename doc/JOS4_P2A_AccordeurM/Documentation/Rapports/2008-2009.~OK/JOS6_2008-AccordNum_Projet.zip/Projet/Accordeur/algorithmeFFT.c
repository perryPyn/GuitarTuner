#include <stdio.h>
#include <math.h>
#define PI (4*atan(1.0))

long int nbr_addition=0;
long int nbr_multiplication=0;

typedef struct complex_t
{
    short int re;
    short int im;
} complex;

//<<complex number prototypes>>=
complex complex_from_polar(short int r, short int theta_radians);
short int complex_magnitude(complex c);
complex complex_add(complex left, complex right);
complex complex_sub(complex left, complex right);
complex complex_mult(complex left, complex right);

//<<complex number function definitions>>=
complex complex_from_polar(short int r, short int theta_radians)
{
    complex result;
    result.re = r * cos(theta_radians);
    result.im = r * sin(theta_radians);
    nbr_multiplication=nbr_multiplication+2;
    return result;
   
}

short int complex_magnitude(complex c)
{
    nbr_multiplication=nbr_multiplication+2;
    nbr_addition++;	
    return sqrt(c.re*c.re + c.im*c.im);
   
}

complex complex_add(complex left, complex right) 
{
    complex result;
    result.re = left.re + right.re;
    result.im = left.im + right.im;
    nbr_addition=nbr_addition+2;
    return result;
   
}

complex complex_sub(complex left, complex right) 
{
    complex result;
    result.re = left.re - right.re;
    result.im = left.im - right.im;
    nbr_addition=nbr_addition+2;
    return result;
    
}

complex complex_mult(complex left, complex right) 
{
    complex result;
    result.re = left.re*right.re - left.im*right.im;
    result.im = left.re*right.im + left.im*right.re;
    nbr_addition=nbr_addition+2;
    nbr_multiplication=nbr_multiplication+4;
    return result;
    
}

//-----------------------------------------------------------------------------------------------

void FFT_calculate(complex* x, int N , int skip, complex* X, complex* D, complex* twiddles) 
{
	complex * E = D + N/2;
	int k;
	nbr_addition++;
	

    	if (N == 1) 
		{
        		X[0] = x[0];
        		return;
    		}

    	/* for now we can use X as a scratch buffer */
    	FFT_calculate(x, N/2, skip*2, E, X, twiddles);
    	FFT_calculate(x + skip, N/2, skip*2, D, X, twiddles);

    	for(k = 0; k < N/2; k++) 
		{
    	    		/* Multiply entries of D by the twiddle factors e^(-2*pi*i/N * k) */
        		D[k] = complex_mult(twiddles[k*skip], D[k]);
		}

   	 for(k = 0; k < N/2; k++) 
		{
       			 X[k]       = complex_add(E[k], D[k]);
       			 X[k + N/2] = complex_sub(E[k], D[k]);
    		}
}

complex* FFT_get_twiddle_factors(int N) 
{
    	complex* twiddles = (complex*) malloc(sizeof(struct complex_t) * N/2);
    	int k;
    	for (k = 0; k != N/2; ++k) 
	{
      		  twiddles[k] = complex_from_polar(1.0, -2.0*PI*k/N);
    	}
    	return twiddles;
}

complex* FFT_simple(complex* x, int N) 
{
	complex* out = (complex*) malloc(sizeof(struct complex_t) * N);
    	complex* scratch = (complex*) malloc(sizeof(struct complex_t) * N);
    	complex* twiddles = FFT_get_twiddle_factors(N);
    	FFT_calculate(x, N, 1, out, scratch, twiddles);
    	free(twiddles);
    	free(scratch);
    	return out;
}

void main(void)
{
	
	int i;
	complex x[1024];
	for (i=0;i<1024;i++)
	{
		x[i].re=rand();
		x[i].im=rand();
	}

	FFT_simple(x,1024);
	clrscr();
	printf("Le nombre d'additions est %i\nLe nombre de multiplications est %i\n",nbr_addition,nbr_multiplication);
	getch();


}