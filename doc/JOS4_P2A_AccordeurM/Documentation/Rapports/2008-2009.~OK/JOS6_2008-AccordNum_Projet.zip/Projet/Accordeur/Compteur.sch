VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "xbr"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL Load(7:0)
        SIGNAL Etat(7:0)
        SIGNAL InitC
        SIGNAL ValidC
        SIGNAL Clk
        SIGNAL ZERO
        SIGNAL UN
        SIGNAL Load(0)
        SIGNAL Load(1)
        SIGNAL Load(2)
        SIGNAL Load(3)
        SIGNAL Load(4)
        SIGNAL Load(5)
        SIGNAL Load(6)
        SIGNAL Load(7)
        SIGNAL Etat(1)
        SIGNAL XLXN_32
        SIGNAL Etat(7)
        SIGNAL XLXN_30
        SIGNAL Etat(6)
        SIGNAL XLXN_28
        SIGNAL Etat(5)
        SIGNAL XLXN_26
        SIGNAL Etat(4)
        SIGNAL XLXN_24
        SIGNAL Etat(3)
        SIGNAL XLXN_22
        SIGNAL Etat(2)
        SIGNAL Etat(0)
        SIGNAL A
        SIGNAL D
        SIGNAL B
        SIGNAL C
        SIGNAL Signe
        PORT Output Etat(7:0)
        PORT Input InitC
        PORT Input ValidC
        PORT Input Clk
        PORT Output Signe
        BEGIN BLOCKDEF cb8cled
            TIMESTAMP 2000 1 1 10 10 10
            RECTANGLE N 0 -460 64 -436 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            RECTANGLE N 320 -460 384 -436 
            RECTANGLE N 64 -512 320 -64 
            LINE N 384 -192 320 -192 
            LINE N 0 -448 64 -448 
            LINE N 384 -448 320 -448 
            LINE N 0 -256 64 -256 
            LINE N 0 -32 64 -32 
            LINE N 0 -128 64 -128 
            LINE N 0 -192 64 -192 
            LINE N 0 -320 64 -320 
            LINE N 384 -128 320 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF buf
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -32 64 -32 
            LINE N 224 -32 128 -32 
            LINE N 64 -64 64 0 
            LINE N 128 -32 64 -64 
            LINE N 64 0 128 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF vcc
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 96 -64 32 -64 
            LINE N 64 0 64 -32 
            LINE N 64 -32 64 -64 
        END BLOCKDEF
        BEGIN BLOCKDEF gnd
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 -128 64 -96 
            LINE N 64 -64 64 -80 
            LINE N 88 -64 40 -64 
            LINE N 68 -32 60 -32 
            LINE N 76 -48 52 -48 
            LINE N 64 -64 64 -96 
        END BLOCKDEF
        BEGIN BLOCKDEF MiniSequenceur
            TIMESTAMP 2009 3 31 12 16 16
            RECTANGLE N 64 -192 320 0 
            LINE N 64 -160 0 -160 
            LINE N 64 -96 0 -96 
            LINE N 64 -32 0 -32 
            LINE N 320 -160 384 -160 
        END BLOCKDEF
        BEGIN BLOCKDEF nor8
            TIMESTAMP 2000 1 1 10 10 10
            ARC N -40 -344 72 -232 48 -240 48 -336 
            LINE N 128 -336 64 -336 
            LINE N 128 -240 64 -240 
            ARC N 44 -416 220 -240 128 -240 208 -288 
            ARC N 44 -336 220 -160 208 -288 128 -336 
            LINE N 256 -288 228 -288 
            CIRCLE N 208 -296 228 -276 
            LINE N 0 -64 48 -64 
            LINE N 0 -128 48 -128 
            LINE N 0 -192 48 -192 
            LINE N 0 -384 48 -384 
            LINE N 0 -448 48 -448 
            LINE N 0 -512 48 -512 
            LINE N 0 -320 64 -320 
            LINE N 0 -256 64 -256 
            LINE N 48 -336 48 -512 
            LINE N 48 -64 48 -240 
            LINE N 72 -336 48 -336 
            LINE N 72 -240 52 -240 
        END BLOCKDEF
        BEGIN BLOCKDEF inv
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -32 64 -32 
            LINE N 224 -32 160 -32 
            LINE N 64 -64 128 -32 
            LINE N 128 -32 64 0 
            LINE N 64 0 64 -64 
            CIRCLE N 128 -48 160 -16 
        END BLOCKDEF
        BEGIN BLOCK XLXI_3 cb8cled
            PIN C Clk
            PIN CE ValidC
            PIN CLR ZERO
            PIN D(7:0) Load(7:0)
            PIN L InitC
            PIN UP Signe
            PIN CEO
            PIN Q(7:0) Etat(7:0)
            PIN TC
        END BLOCK
        BEGIN BLOCK XLXI_12 vcc
            PIN P UN
        END BLOCK
        BEGIN BLOCK XLXI_13 gnd
            PIN G ZERO
        END BLOCK
        BEGIN BLOCK XLXI_21 MiniSequenceur
            PIN E1 D
            PIN E2 InitC
            PIN Clk Clk
            PIN Q Signe
        END BLOCK
        BEGIN BLOCK XLXI_20 buf
            PIN I UN
            PIN O Load(0)
        END BLOCK
        BEGIN BLOCK XLXI_19 buf
            PIN I ZERO
            PIN O Load(1)
        END BLOCK
        BEGIN BLOCK XLXI_18 buf
            PIN I ZERO
            PIN O Load(2)
        END BLOCK
        BEGIN BLOCK XLXI_17 buf
            PIN I UN
            PIN O Load(3)
        END BLOCK
        BEGIN BLOCK XLXI_16 buf
            PIN I UN
            PIN O Load(4)
        END BLOCK
        BEGIN BLOCK XLXI_15 buf
            PIN I UN
            PIN O Load(5)
        END BLOCK
        BEGIN BLOCK XLXI_14 buf
            PIN I UN
            PIN O Load(6)
        END BLOCK
        BEGIN BLOCK XLXI_4 buf
            PIN I UN
            PIN O Load(7)
        END BLOCK
        BEGIN BLOCK XLXI_37 buf
            PIN I Etat(7)
            PIN O XLXN_32
        END BLOCK
        BEGIN BLOCK XLXI_36 buf
            PIN I Etat(6)
            PIN O XLXN_30
        END BLOCK
        BEGIN BLOCK XLXI_35 buf
            PIN I Etat(5)
            PIN O XLXN_28
        END BLOCK
        BEGIN BLOCK XLXI_34 buf
            PIN I Etat(4)
            PIN O XLXN_26
        END BLOCK
        BEGIN BLOCK XLXI_33 buf
            PIN I Etat(3)
            PIN O XLXN_24
        END BLOCK
        BEGIN BLOCK XLXI_32 buf
            PIN I Etat(2)
            PIN O XLXN_22
        END BLOCK
        BEGIN BLOCK XLXI_31 buf
            PIN I Etat(1)
            PIN O C
        END BLOCK
        BEGIN BLOCK XLXI_30 buf
            PIN I Etat(0)
            PIN O A
        END BLOCK
        BEGIN BLOCK XLXI_97 nor8
            PIN I0 XLXN_32
            PIN I1 XLXN_30
            PIN I2 XLXN_28
            PIN I3 XLXN_26
            PIN I4 XLXN_24
            PIN I5 XLXN_22
            PIN I6 C
            PIN I7 B
            PIN O D
        END BLOCK
        BEGIN BLOCK XLXI_98 inv
            PIN I A
            PIN O B
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 1900 1344
        ATTR LengthUnitName "CM"
        ATTR GridsPerUnit "4"
        BEGIN BRANCH Load(7:0)
            WIRE 592 352 640 352
            BEGIN DISPLAY 592 352 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Etat(7:0)
            WIRE 1024 352 1072 352
        END BRANCH
        BEGIN BRANCH Signe
            WIRE 624 480 640 480
            BEGIN DISPLAY 624 480 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH InitC
            WIRE 624 544 640 544
        END BRANCH
        IOMARKER 624 544 InitC R180 28
        BEGIN BRANCH ValidC
            WIRE 624 608 640 608
        END BRANCH
        IOMARKER 624 608 ValidC R180 28
        BEGIN BRANCH Clk
            WIRE 624 672 640 672
        END BRANCH
        IOMARKER 624 672 Clk R180 28
        BEGIN BRANCH ZERO
            WIRE 624 768 640 768
            BEGIN DISPLAY 624 768 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_12 416 80 R0
        INSTANCE XLXI_13 496 208 R0
        BEGIN BRANCH ZERO
            WIRE 560 64 560 80
            BEGIN DISPLAY 560 64 ATTR Name
                ALIGNMENT SOFT-VLEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH UN
            WIRE 480 80 480 96
            BEGIN DISPLAY 480 96 ATTR Name
                ALIGNMENT SOFT-VRIGHT
            END DISPLAY
        END BRANCH
        BEGIN INSTANCE XLXI_21 688 1056 R0
        END INSTANCE
        BEGIN BRANCH D
            WIRE 672 896 688 896
            BEGIN DISPLAY 672 896 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH InitC
            WIRE 672 960 688 960
            BEGIN DISPLAY 672 960 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Clk
            WIRE 672 1024 688 1024
            BEGIN DISPLAY 672 1024 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Signe
            WIRE 1072 896 1088 896
            WIRE 1088 896 1104 896
            WIRE 1104 896 1136 896
            BEGIN DISPLAY 1104 896 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_20 80 560 R0
        INSTANCE XLXI_19 80 496 R0
        INSTANCE XLXI_18 80 432 R0
        INSTANCE XLXI_17 80 368 R0
        INSTANCE XLXI_16 80 304 R0
        INSTANCE XLXI_15 80 240 R0
        INSTANCE XLXI_14 80 176 R0
        INSTANCE XLXI_4 80 112 R0
        BEGIN BRANCH Load(0)
            WIRE 304 528 320 528
            BEGIN DISPLAY 320 528 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH UN
            WIRE 64 528 80 528
            BEGIN DISPLAY 64 528 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Load(1)
            WIRE 304 464 320 464
            BEGIN DISPLAY 320 464 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH ZERO
            WIRE 64 464 80 464
            BEGIN DISPLAY 64 464 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Load(2)
            WIRE 304 400 320 400
            BEGIN DISPLAY 320 400 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH ZERO
            WIRE 64 400 80 400
            BEGIN DISPLAY 64 400 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Load(3)
            WIRE 304 336 320 336
            BEGIN DISPLAY 320 336 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH UN
            WIRE 64 336 80 336
            BEGIN DISPLAY 64 336 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Load(4)
            WIRE 304 272 320 272
            BEGIN DISPLAY 320 272 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH UN
            WIRE 64 272 80 272
            BEGIN DISPLAY 64 272 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Load(5)
            WIRE 304 208 320 208
            BEGIN DISPLAY 320 208 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH UN
            WIRE 64 208 80 208
            BEGIN DISPLAY 64 208 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Load(6)
            WIRE 304 144 320 144
            BEGIN DISPLAY 320 144 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH UN
            WIRE 64 144 80 144
            BEGIN DISPLAY 64 144 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Load(7)
            WIRE 304 80 320 80
            BEGIN DISPLAY 320 80 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH UN
            WIRE 64 80 80 80
            BEGIN DISPLAY 64 80 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_37 1360 656 R0
        INSTANCE XLXI_36 1360 592 R0
        INSTANCE XLXI_35 1360 528 R0
        INSTANCE XLXI_34 1360 464 R0
        INSTANCE XLXI_33 1360 400 R0
        INSTANCE XLXI_32 1360 336 R0
        INSTANCE XLXI_31 1360 272 R0
        INSTANCE XLXI_30 1360 208 R0
        BEGIN BRANCH D
            WIRE 1872 400 1888 400
            BEGIN DISPLAY 1888 400 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_32
            WIRE 1584 624 1600 624
            WIRE 1600 624 1616 624
            BEGIN DISPLAY 1600 624 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Etat(7)
            WIRE 1344 624 1360 624
            BEGIN DISPLAY 1344 624 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_30
            WIRE 1584 560 1600 560
            WIRE 1600 560 1616 560
            BEGIN DISPLAY 1600 560 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Etat(6)
            WIRE 1344 560 1360 560
            BEGIN DISPLAY 1344 560 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_28
            WIRE 1584 496 1600 496
            WIRE 1600 496 1616 496
            BEGIN DISPLAY 1600 496 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Etat(5)
            WIRE 1344 496 1360 496
            BEGIN DISPLAY 1344 496 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_26
            WIRE 1584 432 1600 432
            WIRE 1600 432 1616 432
            BEGIN DISPLAY 1600 432 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Etat(4)
            WIRE 1344 432 1360 432
            BEGIN DISPLAY 1344 432 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_24
            WIRE 1584 368 1600 368
            WIRE 1600 368 1616 368
            BEGIN DISPLAY 1600 368 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Etat(3)
            WIRE 1344 368 1360 368
            BEGIN DISPLAY 1344 368 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH XLXN_22
            WIRE 1584 304 1600 304
            WIRE 1600 304 1616 304
            BEGIN DISPLAY 1600 304 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Etat(2)
            WIRE 1344 304 1360 304
            BEGIN DISPLAY 1344 304 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Etat(0)
            WIRE 1344 176 1360 176
            BEGIN DISPLAY 1344 176 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_3 640 800 R0
        BEGIN BRANCH Etat(1)
            WIRE 1344 240 1360 240
            BEGIN DISPLAY 1344 240 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH C
            WIRE 1584 240 1600 240
            WIRE 1600 240 1616 240
            BEGIN DISPLAY 1600 240 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        IOMARKER 1072 352 Etat(7:0) R0 28
        INSTANCE XLXI_97 1616 688 R0
        INSTANCE XLXI_98 1376 800 R0
        BEGIN BRANCH A
            WIRE 1584 128 1600 128
            WIRE 1600 128 1600 176
            WIRE 1584 176 1600 176
            BEGIN DISPLAY 1584 128 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH B
            WIRE 1616 128 1616 176
            BEGIN DISPLAY 1616 128 ATTR Name
                ALIGNMENT SOFT-VLEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH B
            WIRE 1600 768 1632 768
            BEGIN DISPLAY 1632 768 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH A
            WIRE 1344 768 1376 768
            BEGIN DISPLAY 1344 768 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        IOMARKER 1136 896 Signe R0 28
    END SHEET
END SCHEMATIC
