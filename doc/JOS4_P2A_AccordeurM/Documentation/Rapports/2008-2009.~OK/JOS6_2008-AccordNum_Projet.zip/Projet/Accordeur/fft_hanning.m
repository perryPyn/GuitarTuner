function [valeur,n] = fft_hanning(freq,nbrperiod,Fe,FFT_taille)

Te = 1/Fe;
t = 0:Te:nbrperiod/freq-Te;
n = nbrperiod*Fe/freq;

x = sin(2*pi*freq*t);
subplot(2,1,1);
plot(x);

%Fenetre de Hanning
w = 0.5*(1-cos(2*pi*(0:length(x)-1)'/length(x)));

x = w'.*x;

f = 0:Fe/(FFT_taille):Fe-Fe/(FFT_taille);
X = abs(fft(x,FFT_taille));
subplot(2,1,2);
semilogx(f,X);


[maxX,indice] = max(X);
valeur = ((indice-1)/FFT_taille)*Fe;