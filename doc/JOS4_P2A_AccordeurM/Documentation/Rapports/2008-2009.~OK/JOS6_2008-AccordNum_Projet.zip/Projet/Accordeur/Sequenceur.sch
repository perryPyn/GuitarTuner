VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "xbr"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL XLXN_1
        SIGNAL Mesure
        SIGNAL ChargerR
        SIGNAL InitC
        SIGNAL Clk
        SIGNAL ValidC
        PORT Input Mesure
        PORT Output ChargerR
        PORT Output InitC
        PORT Input Clk
        PORT Output ValidC
        BEGIN BLOCKDEF Etat_Futur
            TIMESTAMP 2009 3 31 14 2 52
            LINE N 64 32 0 32 
            LINE N 320 32 384 32 
            LINE N 64 -96 0 -96 
            RECTANGLE N 64 -256 320 64 
        END BLOCKDEF
        BEGIN BLOCKDEF Sorties
            TIMESTAMP 2009 3 31 13 41 46
            LINE N 64 96 0 96 
            LINE N 64 -32 0 -32 
            LINE N 320 -160 384 -160 
            LINE N 320 -32 384 -32 
            RECTANGLE N 64 -256 320 128 
        END BLOCKDEF
        BEGIN BLOCKDEF fd
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 -112 80 -128 
            LINE N 80 -128 64 -144 
            LINE N 384 -256 320 -256 
            LINE N 0 -256 64 -256 
            LINE N 0 -128 64 -128 
            RECTANGLE N 64 -320 320 -64 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 Etat_Futur
            PIN Mesure Mesure
            PIN Q ValidC
            PIN D XLXN_1
        END BLOCK
        BEGIN BLOCK XLXI_2 Sorties
            PIN Mesure Mesure
            PIN ChargerR ChargerR
            PIN InitC InitC
            PIN Q ValidC
        END BLOCK
        BEGIN BLOCK XLXI_3 fd
            PIN C Clk
            PIN D XLXN_1
            PIN Q ValidC
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 1900 1344
        ATTR LengthUnitName "CM"
        ATTR GridsPerUnit "4"
        INSTANCE XLXI_3 848 656 R0
        BEGIN INSTANCE XLXI_1 368 368 R0
        END INSTANCE
        BEGIN INSTANCE XLXI_2 1312 304 R0
        END INSTANCE
        BEGIN BRANCH XLXN_1
            WIRE 752 400 848 400
        END BRANCH
        BEGIN BRANCH ValidC
            WIRE 1232 400 1264 400
            WIRE 1264 400 1312 400
            WIRE 1264 400 1264 544
            WIRE 1264 544 1744 544
            BEGIN DISPLAY 1264 400 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Mesure
            WIRE 336 272 368 272
        END BRANCH
        IOMARKER 336 272 Mesure R180 28
        BEGIN BRANCH ChargerR
            WIRE 1696 144 1728 144
        END BRANCH
        IOMARKER 1728 144 ChargerR R0 28
        BEGIN BRANCH InitC
            WIRE 1696 272 1728 272
        END BRANCH
        IOMARKER 1728 272 InitC R0 28
        BEGIN BRANCH Clk
            WIRE 816 528 848 528
        END BRANCH
        IOMARKER 816 528 Clk R180 28
        BEGIN BRANCH ValidC
            WIRE 336 400 368 400
            BEGIN DISPLAY 336 400 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Mesure
            WIRE 1280 272 1312 272
            BEGIN DISPLAY 1280 272 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        IOMARKER 1744 544 ValidC R0 28
    END SHEET
END SCHEMATIC
