clear all
clc

erreurSignee = 1;
taillCompt = 256;
freq = 220;

freq2 = (1 + erreurSignee/taillCompt)*freq;
Fe = 44100;
t = 0:1/Fe:2;
x = 1/2*(sin(2*pi*freq*t) + 1/2*sin(2*pi*2*freq*t) + 1/4*sin(2*pi*3*freq*t));
y = 1/2*(sin(2*pi*freq2*t) + 1/2*sin(2*pi*2*freq2*t) + 1/4*sin(2*pi*3*freq2*t));
wavplay(x,Fe);
wavplay(y,Fe);
wavplay(1/2*(x+y),Fe);

% 106,95 % de la fr�quence de r�f�rence correspond au demi-ton