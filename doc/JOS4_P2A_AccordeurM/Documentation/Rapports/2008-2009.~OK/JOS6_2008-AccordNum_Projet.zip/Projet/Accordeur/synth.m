% function [] = synth()

clear all
close all
clc

re = wavread('Re_guitare2');
re = re(1:4:length(re));
wavplay(re,11025);

freq = 144;
Fe = 11025;

finDecay = 0.3;
NfinDecay = round(finDecay*Fe);
NfinSon = length(re);
finSon = NfinSon/Fe; 

for N = 1:NfinDecay,
x(N) = 1/5*(0.8/0.4553-0.75*N/NfinDecay)*(1/2*sin(2*pi*3*freq*N/Fe)+1/3*sin(2*pi*2*freq*N/Fe)+...
    1/3*sin(2*pi*4*freq*N/Fe)+1/2*sin(2*pi*6*freq*N/Fe)+sin(2*pi*7*freq*N/Fe));
end 
for N = NfinDecay+1:NfinSon,
x(N) = 1/5*exp((-N+(NfinDecay+1))/Fe)*(1/2*sin(2*pi*3*freq*N/Fe)+1/3*sin(2*pi*2*freq*N/Fe)+1/3*sin(2*pi*4*...
    freq*N/Fe)+1/2*sin(2*pi*6*freq*N/Fe)+sin(2*pi*7*freq*N/Fe));
end 
wavplay(x,Fe)

FFT_t = 2048;
f = (0:FFT_t/2-1)*Fe/FFT_t;

re_fft = abs(fft(re,FFT_t));
x_fft = abs(fft(x,FFT_t));
subplot(2,2,1), semilogx(f,re_fft(1:length(re_fft)/2));
subplot(2,2,3), semilogx(f,x_fft(1:length(x_fft)/2));
subplot(2,2,2), plot(re);
subplot(2,2,4), plot(x);

