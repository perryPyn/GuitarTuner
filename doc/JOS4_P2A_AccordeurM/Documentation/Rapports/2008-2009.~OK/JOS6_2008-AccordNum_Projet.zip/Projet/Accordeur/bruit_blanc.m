clear all
close all
clc

Fe = 11025;
finSon = 3;
NfinSon = Fe*finSon;
brt_blc = 1/4*randn(1,NfinSon);
% wavplay(brt_blc,Fe)

val_eff = sqrt(1/length(brt_blc)*sum(brt_blc.*brt_blc));

FFT_t = 2048;
f = (0:FFT_t/2-1)*Fe/FFT_t;

brt_blc_fft = abs(fft(brt_blc,FFT_t));
semilogx(f,brt_blc(1:length(brt_blc_fft)/2))
