function [valeur,n] = fft_ferrigno(freq,nbrperiod,Fe,FFT_taille)

Te = 1/Fe;
t = 0:Te:nbrperiod/freq;
n = nbrperiod*Fe/freq;

x = sin(2*pi*freq*t);
subplot(2,1,1);
plot(x);
f = 0:Fe/(FFT_taille):Fe-Fe/(FFT_taille);
X = abs(fft(x,FFT_taille));
subplot(2,1,2);
semilogx(f,X);


[maxX,indice] = max(X);
valeur = (indice/FFT_taille)*Fe;