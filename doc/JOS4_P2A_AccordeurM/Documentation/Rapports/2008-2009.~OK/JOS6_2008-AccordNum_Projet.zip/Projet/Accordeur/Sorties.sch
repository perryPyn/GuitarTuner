VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "xbr"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL ChargerR
        SIGNAL Mesure
        SIGNAL InitC
        SIGNAL Q
        SIGNAL XLXN_22
        PORT Output ChargerR
        PORT Input Mesure
        PORT Output InitC
        PORT Input Q
        BEGIN BLOCKDEF and2b1
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 -48 64 -144 
            LINE N 64 -144 144 -144 
            LINE N 144 -48 64 -48 
            ARC N 96 -144 192 -48 144 -48 144 -144 
            LINE N 256 -96 192 -96 
            LINE N 0 -128 64 -128 
            LINE N 0 -64 40 -64 
            CIRCLE N 40 -76 64 -52 
        END BLOCKDEF
        BEGIN BLOCKDEF inv
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -32 64 -32 
            LINE N 224 -32 160 -32 
            LINE N 64 -64 128 -32 
            LINE N 128 -32 64 0 
            LINE N 64 0 64 -64 
            CIRCLE N 128 -48 160 -16 
        END BLOCKDEF
        BEGIN BLOCK XLXI_13 and2b1
            PIN I0 Mesure
            PIN I1 Q
            PIN O ChargerR
        END BLOCK
        BEGIN BLOCK XLXI_14 inv
            PIN I Q
            PIN O InitC
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 1900 1344
        ATTR LengthUnitName "CM"
        ATTR GridsPerUnit "4"
        INSTANCE XLXI_13 656 656 R0
        BEGIN BRANCH ChargerR
            WIRE 912 560 944 560
        END BRANCH
        IOMARKER 944 560 ChargerR R0 28
        BEGIN BRANCH Mesure
            WIRE 480 592 624 592
            WIRE 624 592 656 592
        END BRANCH
        INSTANCE XLXI_14 656 480 R0
        BEGIN BRANCH InitC
            WIRE 880 448 912 448
        END BRANCH
        IOMARKER 912 448 InitC R0 28
        BEGIN BRANCH Q
            WIRE 512 528 592 528
            WIRE 592 528 640 528
            WIRE 640 528 656 528
            WIRE 592 448 656 448
            WIRE 592 448 592 528
        END BRANCH
        IOMARKER 512 528 Q R180 28
        IOMARKER 480 592 Mesure R180 28
    END SHEET
END SCHEMATIC
