VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "xbr"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL E(8:1)
        SIGNAL E0
        SIGNAL Sor8
        SIGNAL Sor(7:0)
        SIGNAL Etat_mem(7:0)
        SIGNAL Signe_mem
        SIGNAL Affich(7:0)
        SIGNAL Affich8
        SIGNAL E(8)
        SIGNAL E(7)
        SIGNAL E(6)
        SIGNAL E(5)
        SIGNAL E(4)
        SIGNAL E(3)
        SIGNAL E(2)
        SIGNAL E(1)
        SIGNAL Int1
        SIGNAL Int2
        SIGNAL Int3
        SIGNAL Int4
        SIGNAL Sor(4)
        SIGNAL Sor(5)
        SIGNAL Sor(6)
        SIGNAL Sor(7)
        SIGNAL Sor(1)
        SIGNAL Sor(0)
        SIGNAL Sor(2)
        SIGNAL Sor(3)
        PORT Input Etat_mem(7:0)
        PORT Input Signe_mem
        PORT Output Affich(7:0)
        PORT Output Affich8
        BEGIN BLOCKDEF buf8
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -32 64 -32 
            LINE N 64 0 64 -64 
            LINE N 128 -32 64 0 
            LINE N 64 -64 128 -32 
            LINE N 224 -32 128 -32 
            RECTANGLE N 0 -44 64 -20 
            RECTANGLE N 128 -44 224 -20 
        END BLOCKDEF
        BEGIN BLOCKDEF buf
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -32 64 -32 
            LINE N 224 -32 128 -32 
            LINE N 64 -64 64 0 
            LINE N 128 -32 64 -64 
            LINE N 64 0 128 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF nor5
            TIMESTAMP 2000 1 1 10 10 10
            ARC N 28 -240 204 -64 192 -192 112 -240 
            LINE N 112 -240 48 -240 
            LINE N 112 -144 48 -144 
            LINE N 48 -320 48 -240 
            LINE N 48 -64 48 -144 
            ARC N -40 -248 72 -136 48 -144 48 -240 
            ARC N 28 -320 204 -144 112 -144 192 -192 
            LINE N 256 -192 216 -192 
            CIRCLE N 192 -204 216 -180 
            LINE N 0 -320 48 -320 
            LINE N 0 -256 48 -256 
            LINE N 0 -192 72 -192 
            LINE N 0 -128 48 -128 
            LINE N 0 -64 48 -64 
        END BLOCKDEF
        BEGIN BLOCKDEF nor6
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 52 -176 48 -176 
            LINE N 52 -176 68 -176 
            LINE N 48 -272 68 -272 
            LINE N 32 -256 64 -256 
            LINE N 128 -272 64 -272 
            LINE N 48 -64 48 -176 
            LINE N 0 -192 64 -192 
            LINE N 0 -128 48 -128 
            LINE N 0 -64 48 -64 
            LINE N 256 -224 228 -224 
            CIRCLE N 208 -236 228 -216 
            LINE N 0 -384 48 -384 
            LINE N 0 -320 48 -320 
            LINE N 0 -256 64 -256 
            LINE N 48 -272 48 -384 
            ARC N 44 -352 220 -176 128 -176 208 -224 
            LINE N 128 -176 64 -176 
            ARC N 44 -272 220 -96 208 -224 128 -272 
            ARC N -40 -280 72 -168 48 -176 48 -272 
        END BLOCKDEF
        BEGIN BLOCKDEF nor7
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 72 -304 48 -304 
            LINE N 72 -208 48 -208 
            LINE N 48 -64 48 -208 
            LINE N 48 -448 48 -304 
            LINE N 0 -384 48 -384 
            LINE N 0 -448 48 -448 
            LINE N 0 -320 48 -320 
            LINE N 0 -192 48 -192 
            LINE N 0 -128 48 -128 
            LINE N 0 -64 48 -64 
            LINE N 256 -256 228 -256 
            CIRCLE N 208 -264 228 -244 
            ARC N 44 -304 220 -128 208 -256 128 -304 
            LINE N 128 -208 64 -208 
            LINE N 128 -304 64 -304 
            LINE N 0 -256 72 -256 
            ARC N -40 -312 72 -200 48 -208 48 -304 
            ARC N 44 -384 220 -208 128 -208 208 -256 
        END BLOCKDEF
        BEGIN BLOCKDEF nor8
            TIMESTAMP 2000 1 1 10 10 10
            ARC N -40 -344 72 -232 48 -240 48 -336 
            LINE N 128 -336 64 -336 
            LINE N 128 -240 64 -240 
            ARC N 44 -416 220 -240 128 -240 208 -288 
            ARC N 44 -336 220 -160 208 -288 128 -336 
            LINE N 256 -288 228 -288 
            CIRCLE N 208 -296 228 -276 
            LINE N 0 -64 48 -64 
            LINE N 0 -128 48 -128 
            LINE N 0 -192 48 -192 
            LINE N 0 -384 48 -384 
            LINE N 0 -448 48 -448 
            LINE N 0 -512 48 -512 
            LINE N 0 -320 64 -320 
            LINE N 0 -256 64 -256 
            LINE N 48 -336 48 -512 
            LINE N 48 -64 48 -240 
            LINE N 72 -336 48 -336 
            LINE N 72 -240 52 -240 
        END BLOCKDEF
        BEGIN BLOCKDEF nor2b1
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -64 32 -64 
            CIRCLE N 32 -76 56 -52 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 216 -96 
            CIRCLE N 192 -108 216 -84 
            LINE N 112 -48 48 -48 
            LINE N 112 -144 48 -144 
            ARC N 28 -224 204 -48 112 -48 192 -96 
            ARC N 28 -144 204 32 192 -96 112 -144 
            ARC N -40 -152 72 -40 48 -48 48 -144 
        END BLOCKDEF
        BEGIN BLOCKDEF nor2
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 216 -96 
            CIRCLE N 192 -108 216 -84 
            ARC N 28 -224 204 -48 112 -48 192 -96 
            ARC N 28 -144 204 32 192 -96 112 -144 
            ARC N -40 -152 72 -40 48 -48 48 -144 
            LINE N 112 -48 48 -48 
            LINE N 112 -144 48 -144 
        END BLOCKDEF
        BEGIN BLOCK XLXI_3 buf8
            PIN I(7:0) Etat_mem(7:0)
            PIN O(7:0) E(8:1)
        END BLOCK
        BEGIN BLOCK XLXI_10 buf
            PIN I Signe_mem
            PIN O E0
        END BLOCK
        BEGIN BLOCK XLXI_11 buf8
            PIN I(7:0) Sor(7:0)
            PIN O(7:0) Affich(7:0)
        END BLOCK
        BEGIN BLOCK XLXI_12 buf
            PIN I Sor8
            PIN O Affich8
        END BLOCK
        BEGIN BLOCK XLXI_13 nor5
            PIN I0 E(4)
            PIN I1 E(5)
            PIN I2 E(6)
            PIN I3 E(7)
            PIN I4 E(8)
            PIN O Int4
        END BLOCK
        BEGIN BLOCK XLXI_14 nor6
            PIN I0 E(3)
            PIN I1 E(4)
            PIN I2 E(5)
            PIN I3 E(6)
            PIN I4 E(7)
            PIN I5 E(8)
            PIN O Int3
        END BLOCK
        BEGIN BLOCK XLXI_15 nor7
            PIN I0 E(2)
            PIN I1 E(3)
            PIN I2 E(4)
            PIN I3 E(5)
            PIN I4 E(6)
            PIN I5 E(7)
            PIN I6 E(8)
            PIN O Int2
        END BLOCK
        BEGIN BLOCK XLXI_16 nor8
            PIN I0 E(1)
            PIN I1 E(2)
            PIN I2 E(3)
            PIN I3 E(4)
            PIN I4 E(5)
            PIN I5 E(6)
            PIN I6 E(7)
            PIN I7 E(8)
            PIN O Int1
        END BLOCK
        BEGIN BLOCK XLXI_26 nor8
            PIN I0 E(1)
            PIN I1 E(2)
            PIN I2 E(3)
            PIN I3 E(4)
            PIN I4 E(5)
            PIN I5 E(6)
            PIN I6 E(7)
            PIN I7 E(8)
            PIN O Sor8
        END BLOCK
        BEGIN BLOCK XLXI_31 nor2b1
            PIN I0 E0
            PIN I1 Int4
            PIN O Sor(0)
        END BLOCK
        BEGIN BLOCK XLXI_32 nor2b1
            PIN I0 E0
            PIN I1 Int3
            PIN O Sor(1)
        END BLOCK
        BEGIN BLOCK XLXI_33 nor2b1
            PIN I0 E0
            PIN I1 Int2
            PIN O Sor(2)
        END BLOCK
        BEGIN BLOCK XLXI_34 nor2b1
            PIN I0 E0
            PIN I1 Int1
            PIN O Sor(3)
        END BLOCK
        BEGIN BLOCK XLXI_35 nor2
            PIN I0 E0
            PIN I1 Int1
            PIN O Sor(4)
        END BLOCK
        BEGIN BLOCK XLXI_36 nor2
            PIN I0 E0
            PIN I1 Int2
            PIN O Sor(5)
        END BLOCK
        BEGIN BLOCK XLXI_37 nor2
            PIN I0 E0
            PIN I1 Int3
            PIN O Sor(6)
        END BLOCK
        BEGIN BLOCK XLXI_38 nor2
            PIN I0 E0
            PIN I1 Int4
            PIN O Sor(7)
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 1900 1344
        ATTR LengthUnitName "CM"
        ATTR GridsPerUnit "4"
        INSTANCE XLXI_3 32 608 R0
        BEGIN BRANCH E(8:1)
            WIRE 256 576 272 576
            BEGIN DISPLAY 272 576 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_10 32 448 R0
        BEGIN BRANCH E0
            WIRE 256 416 272 416
            BEGIN DISPLAY 272 416 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_11 1600 576 R0
        INSTANCE XLXI_12 1600 672 R0
        BEGIN BRANCH Sor(7:0)
            WIRE 1552 544 1600 544
            BEGIN DISPLAY 1552 544 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Sor8
            WIRE 1568 640 1600 640
            BEGIN DISPLAY 1568 640 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Etat_mem(7:0)
            WIRE 0 576 32 576
        END BRANCH
        IOMARKER 0 576 Etat_mem(7:0) R180 28
        BEGIN BRANCH Signe_mem
            WIRE 0 416 32 416
        END BRANCH
        IOMARKER 0 416 Signe_mem R180 28
        BEGIN BRANCH Affich(7:0)
            WIRE 1824 544 1856 544
        END BRANCH
        IOMARKER 1856 544 Affich(7:0) R0 28
        BEGIN BRANCH Affich8
            WIRE 1824 640 1856 640
        END BRANCH
        IOMARKER 1856 640 Affich8 R0 28
        INSTANCE XLXI_13 656 400 R0
        INSTANCE XLXI_14 656 768 R0
        INSTANCE XLXI_15 656 1200 R0
        INSTANCE XLXI_16 1120 1232 R0
        BEGIN BRANCH E(8)
            WIRE 640 80 656 80
            BEGIN DISPLAY 640 80 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(7)
            WIRE 640 144 656 144
            BEGIN DISPLAY 640 144 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(6)
            WIRE 640 208 656 208
            BEGIN DISPLAY 640 208 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(5)
            WIRE 640 272 656 272
            BEGIN DISPLAY 640 272 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(4)
            WIRE 640 336 656 336
            BEGIN DISPLAY 640 336 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(8)
            WIRE 640 384 656 384
            BEGIN DISPLAY 640 384 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(7)
            WIRE 640 448 656 448
            BEGIN DISPLAY 640 448 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(6)
            WIRE 640 512 656 512
            BEGIN DISPLAY 640 512 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(5)
            WIRE 640 576 656 576
            BEGIN DISPLAY 640 576 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(4)
            WIRE 640 640 656 640
            BEGIN DISPLAY 640 640 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(3)
            WIRE 640 704 656 704
            BEGIN DISPLAY 640 704 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(8)
            WIRE 640 752 656 752
            BEGIN DISPLAY 640 752 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(7)
            WIRE 640 816 656 816
            BEGIN DISPLAY 640 816 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(6)
            WIRE 640 880 656 880
            BEGIN DISPLAY 640 880 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(5)
            WIRE 640 944 656 944
            BEGIN DISPLAY 640 944 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(4)
            WIRE 640 1008 656 1008
            BEGIN DISPLAY 640 1008 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(3)
            WIRE 640 1072 656 1072
            BEGIN DISPLAY 640 1072 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(2)
            WIRE 640 1136 656 1136
            BEGIN DISPLAY 640 1136 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(1)
            WIRE 1104 1168 1120 1168
            BEGIN DISPLAY 1104 1168 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(2)
            WIRE 1104 1104 1120 1104
            BEGIN DISPLAY 1104 1104 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(3)
            WIRE 1104 1040 1120 1040
            BEGIN DISPLAY 1104 1040 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(4)
            WIRE 1104 976 1120 976
            BEGIN DISPLAY 1104 976 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(5)
            WIRE 1104 912 1120 912
            BEGIN DISPLAY 1104 912 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(6)
            WIRE 1104 848 1120 848
            BEGIN DISPLAY 1104 848 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(7)
            WIRE 1104 784 1120 784
            BEGIN DISPLAY 1104 784 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(8)
            WIRE 1104 720 1120 720
            BEGIN DISPLAY 1104 720 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Int1
            WIRE 1376 944 1392 944
            BEGIN DISPLAY 1392 944 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Int2
            WIRE 912 944 928 944
            BEGIN DISPLAY 928 944 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Int3
            WIRE 912 544 928 544
            BEGIN DISPLAY 928 544 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Int4
            WIRE 912 208 928 208
            BEGIN DISPLAY 928 208 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(8)
            WIRE 1072 48 1088 48
            BEGIN DISPLAY 1072 48 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(7)
            WIRE 1072 112 1088 112
            BEGIN DISPLAY 1072 112 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(6)
            WIRE 1072 176 1088 176
            BEGIN DISPLAY 1072 176 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(5)
            WIRE 1072 240 1088 240
            BEGIN DISPLAY 1072 240 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(4)
            WIRE 1072 304 1088 304
            BEGIN DISPLAY 1072 304 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(3)
            WIRE 1072 368 1088 368
            BEGIN DISPLAY 1072 368 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(2)
            WIRE 1072 432 1088 432
            BEGIN DISPLAY 1072 432 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E(1)
            WIRE 1072 496 1088 496
            BEGIN DISPLAY 1072 496 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Sor8
            WIRE 1344 272 1360 272
            BEGIN DISPLAY 1360 272 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Int4
            WIRE 1584 32 1600 32
            BEGIN DISPLAY 1584 32 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E0
            WIRE 1584 96 1600 96
            BEGIN DISPLAY 1584 96 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Int3
            WIRE 1584 128 1600 128
            BEGIN DISPLAY 1584 128 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E0
            WIRE 1584 192 1600 192
            BEGIN DISPLAY 1584 192 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Int2
            WIRE 1584 224 1600 224
            BEGIN DISPLAY 1584 224 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E0
            WIRE 1584 288 1600 288
            BEGIN DISPLAY 1584 288 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Int1
            WIRE 1584 320 1600 320
            BEGIN DISPLAY 1584 320 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E0
            WIRE 1584 384 1600 384
            BEGIN DISPLAY 1584 384 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Sor(3)
            WIRE 1856 352 1872 352
            BEGIN DISPLAY 1872 352 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Sor(2)
            WIRE 1856 256 1872 256
            BEGIN DISPLAY 1872 256 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Sor(1)
            WIRE 1856 160 1872 160
            BEGIN DISPLAY 1872 160 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Sor(0)
            WIRE 1856 64 1872 64
            BEGIN DISPLAY 1872 64 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Sor(4)
            WIRE 1824 784 1840 784
            BEGIN DISPLAY 1840 784 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Sor(5)
            WIRE 1824 880 1840 880
            BEGIN DISPLAY 1840 880 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Sor(6)
            WIRE 1824 976 1840 976
            BEGIN DISPLAY 1840 976 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Sor(7)
            WIRE 1824 1072 1840 1072
            BEGIN DISPLAY 1840 1072 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E0
            WIRE 1552 1104 1568 1104
            BEGIN DISPLAY 1552 1104 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Int4
            WIRE 1552 1040 1568 1040
            BEGIN DISPLAY 1552 1040 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E0
            WIRE 1552 1008 1568 1008
            BEGIN DISPLAY 1552 1008 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Int3
            WIRE 1552 944 1568 944
            BEGIN DISPLAY 1552 944 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E0
            WIRE 1552 912 1568 912
            BEGIN DISPLAY 1552 912 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Int2
            WIRE 1552 848 1568 848
            BEGIN DISPLAY 1552 848 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E0
            WIRE 1552 816 1568 816
            BEGIN DISPLAY 1552 816 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Int1
            WIRE 1552 752 1568 752
            BEGIN DISPLAY 1552 752 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_26 1088 560 R0
        INSTANCE XLXI_31 1600 160 R0
        INSTANCE XLXI_32 1600 256 R0
        INSTANCE XLXI_33 1600 352 R0
        INSTANCE XLXI_34 1600 448 R0
        INSTANCE XLXI_35 1568 880 R0
        INSTANCE XLXI_36 1568 976 R0
        INSTANCE XLXI_37 1568 1072 R0
        INSTANCE XLXI_38 1568 1168 R0
    END SHEET
END SCHEMATIC
