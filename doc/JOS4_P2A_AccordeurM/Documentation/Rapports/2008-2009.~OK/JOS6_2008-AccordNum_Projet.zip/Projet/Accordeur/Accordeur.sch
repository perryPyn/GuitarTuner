VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "xbr"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL Affich(7:0)
        SIGNAL XLXN_20
        SIGNAL XLXN_21
        SIGNAL Affich8
        SIGNAL E_Freq_Guit
        SIGNAL E_Freq_Ref
        SIGNAL Affich(0)
        SIGNAL S_0
        SIGNAL Affich(1)
        SIGNAL S_1
        SIGNAL Affich(2)
        SIGNAL S_2
        SIGNAL Affich(3)
        SIGNAL S_3
        SIGNAL Affich(4)
        SIGNAL S_4
        SIGNAL Affich(5)
        SIGNAL S_5
        SIGNAL Affich(6)
        SIGNAL S_6
        SIGNAL Affich(7)
        SIGNAL S_7
        SIGNAL S_8
        PORT Input E_Freq_Guit
        PORT Input E_Freq_Ref
        PORT Output S_0
        PORT Output S_1
        PORT Output S_2
        PORT Output S_3
        PORT Output S_4
        PORT Output S_5
        PORT Output S_6
        PORT Output S_7
        PORT Output S_8
        BEGIN BLOCKDEF bufg
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 0 128 -32 
            LINE N 128 -32 64 -64 
            LINE N 64 -64 64 0 
            LINE N 224 -32 128 -32 
            LINE N 0 -32 64 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF obuf
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 0 64 -64 
            LINE N 128 -32 64 0 
            LINE N 64 -64 128 -32 
            LINE N 0 -32 64 -32 
            LINE N 224 -32 128 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF Tout
            TIMESTAMP 2009 4 28 12 40 2
            RECTANGLE N 64 -128 320 0 
            LINE N 64 -96 0 -96 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -108 384 -84 
            LINE N 320 -96 384 -96 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF ibuf
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 0 64 -64 
            LINE N 128 -32 64 0 
            LINE N 64 -64 128 -32 
            LINE N 224 -32 128 -32 
            LINE N 0 -32 64 -32 
        END BLOCKDEF
        BEGIN BLOCK XLXI_3 bufg
            PIN I E_Freq_Ref
            PIN O XLXN_21
        END BLOCK
        BEGIN BLOCK XLXI_4 obuf
            PIN I Affich(0)
            PIN O S_0
        END BLOCK
        BEGIN BLOCK XLXI_5 obuf
            PIN I Affich(1)
            PIN O S_1
        END BLOCK
        BEGIN BLOCK XLXI_6 obuf
            PIN I Affich(2)
            PIN O S_2
        END BLOCK
        BEGIN BLOCK XLXI_7 obuf
            PIN I Affich(3)
            PIN O S_3
        END BLOCK
        BEGIN BLOCK XLXI_8 obuf
            PIN I Affich(4)
            PIN O S_4
        END BLOCK
        BEGIN BLOCK XLXI_9 obuf
            PIN I Affich(5)
            PIN O S_5
        END BLOCK
        BEGIN BLOCK XLXI_10 obuf
            PIN I Affich(6)
            PIN O S_6
        END BLOCK
        BEGIN BLOCK XLXI_11 obuf
            PIN I Affich(7)
            PIN O S_7
        END BLOCK
        BEGIN BLOCK XLXI_12 obuf
            PIN I Affich8
            PIN O S_8
        END BLOCK
        BEGIN BLOCK XLXI_13 Tout
            PIN Freq_guit XLXN_20
            PIN Freq_ref XLXN_21
            PIN Affich(7:0) Affich(7:0)
            PIN Affich8 Affich8
        END BLOCK
        BEGIN BLOCK XLXI_14 ibuf
            PIN I E_Freq_Guit
            PIN O XLXN_20
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 1900 1344
        ATTR LengthUnitName "CM"
        ATTR GridsPerUnit "4"
        INSTANCE XLXI_3 464 640 R0
        BEGIN BRANCH Affich(7:0)
            WIRE 1088 544 1104 544
        END BRANCH
        BEGIN BRANCH XLXN_20
            WIRE 688 544 704 544
        END BRANCH
        BEGIN BRANCH XLXN_21
            WIRE 688 608 704 608
        END BRANCH
        BEGIN BRANCH Affich8
            WIRE 1088 608 1104 608
            BEGIN DISPLAY 1104 608 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E_Freq_Guit
            WIRE 432 544 464 544
        END BRANCH
        IOMARKER 432 544 E_Freq_Guit R180 28
        BEGIN BRANCH E_Freq_Ref
            WIRE 432 608 464 608
        END BRANCH
        IOMARKER 432 608 E_Freq_Ref R180 28
        INSTANCE XLXI_4 1328 288 R0
        BEGIN BRANCH Affich(0)
            WIRE 1312 256 1328 256
            BEGIN DISPLAY 1312 256 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH S_0
            WIRE 1552 256 1568 256
        END BRANCH
        INSTANCE XLXI_5 1328 352 R0
        BEGIN BRANCH Affich(1)
            WIRE 1312 320 1328 320
            BEGIN DISPLAY 1312 320 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH S_1
            WIRE 1552 320 1568 320
        END BRANCH
        INSTANCE XLXI_6 1328 416 R0
        BEGIN BRANCH Affich(2)
            WIRE 1312 384 1328 384
            BEGIN DISPLAY 1312 384 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH S_2
            WIRE 1552 384 1568 384
        END BRANCH
        INSTANCE XLXI_7 1328 480 R0
        BEGIN BRANCH Affich(3)
            WIRE 1312 448 1328 448
            BEGIN DISPLAY 1312 448 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH S_3
            WIRE 1552 448 1568 448
        END BRANCH
        INSTANCE XLXI_8 1328 544 R0
        BEGIN BRANCH Affich(4)
            WIRE 1312 512 1328 512
            BEGIN DISPLAY 1312 512 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH S_4
            WIRE 1552 512 1568 512
        END BRANCH
        INSTANCE XLXI_9 1328 608 R0
        BEGIN BRANCH Affich(5)
            WIRE 1312 576 1328 576
            BEGIN DISPLAY 1312 576 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH S_5
            WIRE 1552 576 1568 576
        END BRANCH
        INSTANCE XLXI_10 1328 672 R0
        BEGIN BRANCH Affich(6)
            WIRE 1312 640 1328 640
            BEGIN DISPLAY 1312 640 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH S_6
            WIRE 1552 640 1568 640
        END BRANCH
        INSTANCE XLXI_11 1328 736 R0
        BEGIN BRANCH Affich(7)
            WIRE 1312 704 1328 704
            BEGIN DISPLAY 1312 704 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH S_7
            WIRE 1552 704 1568 704
        END BRANCH
        INSTANCE XLXI_12 1328 800 R0
        BEGIN BRANCH Affich8
            WIRE 1312 768 1328 768
            BEGIN DISPLAY 1312 768 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH S_8
            WIRE 1552 768 1568 768
        END BRANCH
        IOMARKER 1568 256 S_0 R0 28
        IOMARKER 1568 320 S_1 R0 28
        IOMARKER 1568 384 S_2 R0 28
        IOMARKER 1568 448 S_3 R0 28
        IOMARKER 1568 512 S_4 R0 28
        IOMARKER 1568 576 S_5 R0 28
        IOMARKER 1568 640 S_6 R0 28
        IOMARKER 1568 704 S_7 R0 28
        IOMARKER 1568 768 S_8 R0 28
        BEGIN INSTANCE XLXI_13 704 640 R0
        END INSTANCE
        INSTANCE XLXI_14 464 576 R0
    END SHEET
END SCHEMATIC
