--------------------------------------------------------------------------------
-- Copyright (c) 1995-2007 Xilinx, Inc.  All rights reserved.
--------------------------------------------------------------------------------
--   ____  ____ 
--  /   /\/   / 
-- /___/  \  /    Vendor: Xilinx 
-- \   \   \/     Version : 9.2i
--  \   \         Application : sch2vhdl
--  /   /         Filename : Accordeur.vhf
-- /___/   /\     Timestamp : 06/02/2009 13:26:20
-- \   \  /  \ 
--  \___\/\___\ 
--
--Command: D:\Programmes\Xilinx\bin\nt\sch2vhdl.exe -intstyle ise -family xbr -flat -suppress -w D:/Mes_travaux/Projet/Accordeur.sch Accordeur.vhf
--Design Name: Accordeur
--Device: xbr
--Purpose:
--    This vhdl netlist is translated from an ECS schematic. It can be 
--    synthesis and simulted, but it should not be modified. 
--

library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
library UNISIM;
use UNISIM.Vcomponents.ALL;

entity Accordeur is
   port ( E_Freq_Guit : in    std_logic; 
          E_Freq_Ref  : in    std_logic; 
          S_0         : out   std_logic; 
          S_1         : out   std_logic; 
          S_2         : out   std_logic; 
          S_3         : out   std_logic; 
          S_4         : out   std_logic; 
          S_5         : out   std_logic; 
          S_6         : out   std_logic; 
          S_7         : out   std_logic; 
          S_8         : out   std_logic);
end Accordeur;

architecture BEHAVIORAL of Accordeur is
   attribute BOX_TYPE   : string ;
   signal Affich      : std_logic_vector (7 downto 0);
   signal Affich8     : std_logic;
   signal XLXN_20     : std_logic;
   signal XLXN_21     : std_logic;
   component BUFG
      port ( I : in    std_logic; 
             O : out   std_logic);
   end component;
   attribute BOX_TYPE of BUFG : component is "BLACK_BOX";
   
   component OBUF
      port ( I : in    std_logic; 
             O : out   std_logic);
   end component;
   attribute BOX_TYPE of OBUF : component is "BLACK_BOX";
   
   component Tout
      port ( Freq_guit : in    std_logic; 
             Freq_ref  : in    std_logic; 
             Affich    : out   std_logic_vector (7 downto 0); 
             Affich8   : out   std_logic);
   end component;
   
   component IBUF
      port ( I : in    std_logic; 
             O : out   std_logic);
   end component;
   attribute BOX_TYPE of IBUF : component is "BLACK_BOX";
   
begin
   XLXI_3 : BUFG
      port map (I=>E_Freq_Ref,
                O=>XLXN_21);
   
   XLXI_4 : OBUF
      port map (I=>Affich(0),
                O=>S_0);
   
   XLXI_5 : OBUF
      port map (I=>Affich(1),
                O=>S_1);
   
   XLXI_6 : OBUF
      port map (I=>Affich(2),
                O=>S_2);
   
   XLXI_7 : OBUF
      port map (I=>Affich(3),
                O=>S_3);
   
   XLXI_8 : OBUF
      port map (I=>Affich(4),
                O=>S_4);
   
   XLXI_9 : OBUF
      port map (I=>Affich(5),
                O=>S_5);
   
   XLXI_10 : OBUF
      port map (I=>Affich(6),
                O=>S_6);
   
   XLXI_11 : OBUF
      port map (I=>Affich(7),
                O=>S_7);
   
   XLXI_12 : OBUF
      port map (I=>Affich8,
                O=>S_8);
   
   XLXI_13 : Tout
      port map (Freq_guit=>XLXN_20,
                Freq_ref=>XLXN_21,
                Affich(7 downto 0)=>Affich(7 downto 0),
                Affich8=>Affich8);
   
   XLXI_14 : IBUF
      port map (I=>E_Freq_Guit,
                O=>XLXN_20);
   
end BEHAVIORAL;


