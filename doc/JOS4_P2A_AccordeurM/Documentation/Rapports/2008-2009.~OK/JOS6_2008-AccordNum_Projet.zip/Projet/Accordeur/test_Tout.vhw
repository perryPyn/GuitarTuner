--------------------------------------------------------------------------------
-- Copyright (c) 1995-2007 Xilinx, Inc.
-- All Right Reserved.
--------------------------------------------------------------------------------
--   ____  ____ 
--  /   /\/   / 
-- /___/  \  /    Vendor: Xilinx 
-- \   \   \/     Version : 9.2i
--  \   \         Application : ISE
--  /   /         Filename : test_Tout.vhw
-- /___/   /\     Timestamp : Mon Jun 01 11:55:37 2009
-- \   \  /  \ 
--  \___\/\___\ 
--
--Command: 
--Design Name: test_Tout
--Device: Xilinx
--

library UNISIM;
use UNISIM.Vcomponents.ALL;
library ieee;
use ieee.std_logic_1164.ALL;
use ieee.numeric_std.ALL;
USE IEEE.STD_LOGIC_TEXTIO.ALL;
USE IEEE.STD_LOGIC_ARITH.ALL;
USE IEEE.STD_LOGIC_UNSIGNED.ALL;
USE STD.TEXTIO.ALL;

ENTITY test_Tout IS
END test_Tout;

ARCHITECTURE testbench_arch OF test_Tout IS
    FILE RESULTS: TEXT OPEN WRITE_MODE IS "results.txt";

    COMPONENT Tout
        PORT (
            Freq_guit : In std_logic;
            Freq_ref : In std_logic;
            Affich : Out std_logic_vector (7 DownTo 0);
            Affich8 : Out std_logic
        );
    END COMPONENT;

    SIGNAL Freq_guit : std_logic := '0';
    SIGNAL Freq_ref : std_logic := '0';
    SIGNAL Affich : std_logic_vector (7 DownTo 0) := "00000000";
    SIGNAL Affich8 : std_logic := '0';

    constant PERIOD_Freq_guit : time := 2200 ns;
    constant DUTY_CYCLE_Freq_guit : real := 0.5;
    constant OFFSET_Freq_guit : time := 45 ns;
    constant PERIOD_Freq_ref : time := 2000 ns;
    constant DUTY_CYCLE_Freq_ref : real := 0.5;
    constant OFFSET_Freq_ref : time := 0 ns;

    BEGIN
        UUT : Tout
        PORT MAP (
            Freq_guit => Freq_guit,
            Freq_ref => Freq_ref,
            Affich => Affich,
            Affich8 => Affich8
        );

        PROCESS    -- clock process for Freq_guit
        BEGIN
            WAIT for OFFSET_Freq_guit;
            CLOCK_LOOP : LOOP
                Freq_guit <= '0';
                WAIT FOR (PERIOD_Freq_guit - (PERIOD_Freq_guit * DUTY_CYCLE_Freq_guit));
                Freq_guit <= '1';
                WAIT FOR (PERIOD_Freq_guit * DUTY_CYCLE_Freq_guit);
            END LOOP CLOCK_LOOP;
        END PROCESS;

        PROCESS    -- clock process for Freq_ref
        BEGIN
            WAIT for OFFSET_Freq_ref;
            CLOCK_LOOP : LOOP
                Freq_ref <= '0';
                WAIT FOR (PERIOD_Freq_ref - (PERIOD_Freq_ref * DUTY_CYCLE_Freq_ref));
                Freq_ref <= '1';
                WAIT FOR (PERIOD_Freq_ref * DUTY_CYCLE_Freq_ref);
            END LOOP CLOCK_LOOP;
        END PROCESS;

        PROCESS    -- Process for Freq_ref
            BEGIN
                WAIT FOR 5.0022e+006 ns;

            END PROCESS;

    END testbench_arch;

