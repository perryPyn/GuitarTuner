VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "xbr"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL Load(7)
        SIGNAL Load(6)
        SIGNAL Load(5)
        SIGNAL Load(4)
        SIGNAL Load(3)
        SIGNAL ZERO
        SIGNAL Load(2)
        SIGNAL Load(1)
        SIGNAL Load(0)
        SIGNAL Load(7:0)
        SIGNAL Freq_in
        SIGNAL Etat(0)
        SIGNAL Etat(1)
        SIGNAL Etat(2)
        SIGNAL Etat(3)
        SIGNAL Etat(4)
        SIGNAL Etat(5)
        SIGNAL Etat(6)
        SIGNAL Etat(7)
        SIGNAL XLXN_131
        SIGNAL E1
        SIGNAL Etat(7:0)
        SIGNAL L
        SIGNAL UN
        SIGNAL Mesure
        SIGNAL E7
        SIGNAL E6
        SIGNAL E5
        SIGNAL E4
        SIGNAL E3
        SIGNAL E2
        SIGNAL E0
        PORT Input Freq_in
        PORT Output Mesure
        BEGIN BLOCKDEF buf
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -32 64 -32 
            LINE N 224 -32 128 -32 
            LINE N 64 -64 64 0 
            LINE N 128 -32 64 -64 
            LINE N 64 0 128 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF gnd
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 -128 64 -96 
            LINE N 64 -64 64 -80 
            LINE N 88 -64 40 -64 
            LINE N 68 -32 60 -32 
            LINE N 76 -48 52 -48 
            LINE N 64 -64 64 -96 
        END BLOCKDEF
        BEGIN BLOCKDEF cb8cle
            TIMESTAMP 2000 1 1 10 10 10
            RECTANGLE N 64 -448 320 -64 
            LINE N 0 -192 64 -192 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            LINE N 0 -128 64 -128 
            LINE N 0 -32 64 -32 
            LINE N 0 -256 64 -256 
            LINE N 0 -384 64 -384 
            RECTANGLE N 0 -396 64 -372 
            LINE N 384 -384 320 -384 
            LINE N 384 -192 320 -192 
            RECTANGLE N 320 -396 384 -372 
            LINE N 384 -128 320 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF inv
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -32 64 -32 
            LINE N 224 -32 160 -32 
            LINE N 64 -64 128 -32 
            LINE N 128 -32 64 0 
            LINE N 64 0 64 -64 
            CIRCLE N 128 -48 160 -16 
        END BLOCKDEF
        BEGIN BLOCKDEF and8
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 -64 64 -512 
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 0 -192 64 -192 
            LINE N 0 -256 64 -256 
            LINE N 0 -320 64 -320 
            LINE N 0 -384 64 -384 
            LINE N 0 -448 64 -448 
            LINE N 0 -512 64 -512 
            LINE N 64 -336 144 -336 
            LINE N 144 -240 64 -240 
            ARC N 96 -336 192 -240 144 -240 144 -336 
            LINE N 256 -288 192 -288 
        END BLOCKDEF
        BEGIN BLOCKDEF vcc
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 96 -64 32 -64 
            LINE N 64 0 64 -32 
            LINE N 64 -32 64 -64 
        END BLOCKDEF
        BEGIN BLOCKDEF or7
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -256 72 -256 
            LINE N 0 -64 48 -64 
            LINE N 0 -128 48 -128 
            LINE N 0 -192 48 -192 
            LINE N 0 -320 48 -320 
            LINE N 0 -448 48 -448 
            LINE N 0 -384 48 -384 
            LINE N 256 -256 192 -256 
            ARC N 28 -304 204 -128 192 -256 112 -304 
            LINE N 112 -208 48 -208 
            ARC N 28 -384 204 -208 112 -208 192 -256 
            LINE N 112 -304 48 -304 
            LINE N 48 -448 48 -304 
            LINE N 48 -64 48 -208 
            ARC N -40 -312 72 -200 48 -208 48 -304 
        END BLOCKDEF
        BEGIN BLOCK XLXI_4 buf
            PIN I ZERO
            PIN O Load(7)
        END BLOCK
        BEGIN BLOCK XLXI_14 buf
            PIN I ZERO
            PIN O Load(6)
        END BLOCK
        BEGIN BLOCK XLXI_15 buf
            PIN I ZERO
            PIN O Load(5)
        END BLOCK
        BEGIN BLOCK XLXI_16 buf
            PIN I ZERO
            PIN O Load(4)
        END BLOCK
        BEGIN BLOCK XLXI_17 buf
            PIN I ZERO
            PIN O Load(3)
        END BLOCK
        BEGIN BLOCK XLXI_18 buf
            PIN I ZERO
            PIN O Load(2)
        END BLOCK
        BEGIN BLOCK XLXI_19 buf
            PIN I ZERO
            PIN O Load(1)
        END BLOCK
        BEGIN BLOCK XLXI_20 buf
            PIN I ZERO
            PIN O Load(0)
        END BLOCK
        BEGIN BLOCK XLXI_13 gnd
            PIN G ZERO
        END BLOCK
        BEGIN BLOCK XLXI_23 cb8cle
            PIN C Freq_in
            PIN CE UN
            PIN CLR ZERO
            PIN D(7:0) Load(7:0)
            PIN L L
            PIN CEO
            PIN Q(7:0) Etat(7:0)
            PIN TC
        END BLOCK
        BEGIN BLOCK XLXI_24 buf
            PIN I Etat(0)
            PIN O E0
        END BLOCK
        BEGIN BLOCK XLXI_49 buf
            PIN I Etat(1)
            PIN O E1
        END BLOCK
        BEGIN BLOCK XLXI_50 buf
            PIN I Etat(2)
            PIN O E2
        END BLOCK
        BEGIN BLOCK XLXI_51 buf
            PIN I Etat(3)
            PIN O E3
        END BLOCK
        BEGIN BLOCK XLXI_52 buf
            PIN I Etat(4)
            PIN O E4
        END BLOCK
        BEGIN BLOCK XLXI_53 buf
            PIN I Etat(5)
            PIN O E5
        END BLOCK
        BEGIN BLOCK XLXI_54 buf
            PIN I Etat(6)
            PIN O E6
        END BLOCK
        BEGIN BLOCK XLXI_55 buf
            PIN I Etat(7)
            PIN O E7
        END BLOCK
        BEGIN BLOCK XLXI_66 inv
            PIN I E2
            PIN O XLXN_131
        END BLOCK
        BEGIN BLOCK XLXI_104 and8
            PIN I0 E7
            PIN I1 E6
            PIN I2 E5
            PIN I3 E4
            PIN I4 E3
            PIN I5 XLXN_131
            PIN I6 E1
            PIN I7 E0
            PIN O L
        END BLOCK
        BEGIN BLOCK XLXI_107 vcc
            PIN P UN
        END BLOCK
        BEGIN BLOCK XLXI_115 or7
            PIN I0 E7
            PIN I1 E6
            PIN I2 E5
            PIN I3 E4
            PIN I4 E3
            PIN I5 E2
            PIN I6 E1
            PIN O Mesure
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 1900 1344
        ATTR LengthUnitName "CM"
        ATTR GridsPerUnit "4"
        INSTANCE XLXI_4 128 80 R0
        BEGIN BRANCH ZERO
            WIRE 112 48 128 48
            BEGIN DISPLAY 112 48 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Load(7)
            WIRE 352 48 368 48
            BEGIN DISPLAY 368 48 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_14 128 144 R0
        BEGIN BRANCH ZERO
            WIRE 112 112 128 112
            BEGIN DISPLAY 112 112 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Load(6)
            WIRE 352 112 368 112
            BEGIN DISPLAY 368 112 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_15 128 208 R0
        BEGIN BRANCH ZERO
            WIRE 112 176 128 176
            BEGIN DISPLAY 112 176 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Load(5)
            WIRE 352 176 368 176
            BEGIN DISPLAY 368 176 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_16 128 272 R0
        BEGIN BRANCH ZERO
            WIRE 112 240 128 240
            BEGIN DISPLAY 112 240 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Load(4)
            WIRE 352 240 368 240
            BEGIN DISPLAY 368 240 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_17 128 336 R0
        BEGIN BRANCH ZERO
            WIRE 112 304 128 304
            BEGIN DISPLAY 112 304 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Load(3)
            WIRE 352 304 368 304
            BEGIN DISPLAY 368 304 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_18 128 400 R0
        BEGIN BRANCH ZERO
            WIRE 112 368 128 368
            BEGIN DISPLAY 112 368 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Load(2)
            WIRE 352 368 368 368
            BEGIN DISPLAY 368 368 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_19 128 464 R0
        BEGIN BRANCH ZERO
            WIRE 112 432 128 432
            BEGIN DISPLAY 112 432 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Load(1)
            WIRE 352 432 368 432
            BEGIN DISPLAY 368 432 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_20 128 528 R0
        BEGIN BRANCH ZERO
            WIRE 112 496 128 496
            BEGIN DISPLAY 112 496 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Load(0)
            WIRE 352 496 368 496
            BEGIN DISPLAY 368 496 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_13 112 832 R0
        BEGIN BRANCH ZERO
            WIRE 176 688 176 704
            BEGIN DISPLAY 176 688 ATTR Name
                ALIGNMENT SOFT-VLEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Load(7:0)
            WIRE 624 112 640 112
            BEGIN DISPLAY 624 112 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Freq_in
            WIRE 608 368 640 368
        END BRANCH
        BEGIN BRANCH UN
            WIRE 608 304 624 304
            WIRE 624 304 640 304
            BEGIN DISPLAY 624 304 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_23 640 496 R0
        INSTANCE XLXI_24 960 560 R0
        BEGIN BRANCH Etat(0)
            WIRE 944 528 960 528
            BEGIN DISPLAY 944 528 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_49 960 624 R0
        BEGIN BRANCH Etat(1)
            WIRE 944 592 960 592
            BEGIN DISPLAY 944 592 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E1
            WIRE 1184 592 1216 592
            WIRE 1216 592 1456 592
            BEGIN DISPLAY 1216 592 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_50 960 688 R0
        BEGIN BRANCH Etat(2)
            WIRE 944 656 960 656
            BEGIN DISPLAY 944 656 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E2
            WIRE 1184 656 1200 656
            WIRE 1200 656 1216 656
            BEGIN DISPLAY 1200 656 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_51 960 752 R0
        BEGIN BRANCH Etat(3)
            WIRE 944 720 960 720
            BEGIN DISPLAY 944 720 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E3
            WIRE 1184 720 1216 720
            WIRE 1216 720 1456 720
            BEGIN DISPLAY 1216 720 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_52 960 816 R0
        BEGIN BRANCH Etat(4)
            WIRE 944 784 960 784
            BEGIN DISPLAY 944 784 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E4
            WIRE 1184 784 1216 784
            WIRE 1216 784 1456 784
            BEGIN DISPLAY 1216 784 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_53 960 880 R0
        BEGIN BRANCH Etat(5)
            WIRE 944 848 960 848
            BEGIN DISPLAY 944 848 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E5
            WIRE 1184 848 1216 848
            WIRE 1216 848 1456 848
            BEGIN DISPLAY 1216 848 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_54 960 944 R0
        BEGIN BRANCH Etat(6)
            WIRE 944 912 960 912
            BEGIN DISPLAY 944 912 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E6
            WIRE 1184 912 1216 912
            WIRE 1216 912 1456 912
            BEGIN DISPLAY 1216 912 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_55 960 1008 R0
        BEGIN BRANCH Etat(7)
            WIRE 944 976 960 976
            BEGIN DISPLAY 944 976 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E7
            WIRE 1184 976 1216 976
            WIRE 1216 976 1456 976
            BEGIN DISPLAY 1216 976 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_104 1456 1040 R0
        BEGIN BRANCH XLXN_131
            WIRE 1440 656 1456 656
        END BRANCH
        BEGIN BRANCH L
            WIRE 1712 752 1744 752
            BEGIN DISPLAY 1744 752 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Etat(7:0)
            WIRE 1024 112 1056 112
            BEGIN DISPLAY 1056 112 ATTR Name
                ALIGNMENT SOFT-LEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH L
            WIRE 608 240 640 240
            BEGIN DISPLAY 608 240 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH ZERO
            WIRE 608 464 640 464
            BEGIN DISPLAY 608 464 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        IOMARKER 608 368 Freq_in R180 28
        INSTANCE XLXI_107 16 688 R0
        BEGIN BRANCH UN
            WIRE 80 688 80 704
            WIRE 80 704 80 720
            BEGIN DISPLAY 80 704 ATTR Name
                ALIGNMENT SOFT-TVCENTER
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Mesure
            WIRE 1728 240 1776 240
        END BRANCH
        IOMARKER 1776 240 Mesure R0 28
        BEGIN BRANCH E7
            WIRE 1456 432 1472 432
            BEGIN DISPLAY 1456 432 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_66 1216 688 R0
        BEGIN BRANCH E0
            WIRE 1184 528 1200 528
            WIRE 1200 528 1216 528
            WIRE 1216 528 1440 528
            WIRE 1440 528 1456 528
            BEGIN DISPLAY 1200 528 ATTR Name
                ALIGNMENT SOFT-BCENTER
            END DISPLAY
        END BRANCH
        INSTANCE XLXI_115 1472 496 R0
        BEGIN BRANCH E6
            WIRE 1456 368 1472 368
            BEGIN DISPLAY 1456 368 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E5
            WIRE 1456 304 1472 304
            BEGIN DISPLAY 1456 304 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E4
            WIRE 1456 240 1472 240
            BEGIN DISPLAY 1456 240 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E3
            WIRE 1456 176 1472 176
            BEGIN DISPLAY 1456 176 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E2
            WIRE 1456 112 1472 112
            BEGIN DISPLAY 1456 112 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E1
            WIRE 1456 48 1472 48
            BEGIN DISPLAY 1456 48 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
    END SHEET
END SCHEMATIC
