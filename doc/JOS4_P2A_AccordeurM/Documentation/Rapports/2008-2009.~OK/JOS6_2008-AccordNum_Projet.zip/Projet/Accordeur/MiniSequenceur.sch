VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "xbr"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL XLXN_1
        SIGNAL XLXN_2
        SIGNAL E1
        SIGNAL Q
        SIGNAL E2
        SIGNAL S
        SIGNAL Clk
        PORT Input E1
        PORT Output Q
        PORT Input E2
        PORT Input Clk
        BEGIN BLOCKDEF or2
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 0 -64 64 -64 
            LINE N 0 -128 64 -128 
            LINE N 256 -96 192 -96 
            ARC N 28 -224 204 -48 112 -48 192 -96 
            ARC N -40 -152 72 -40 48 -48 48 -144 
            LINE N 112 -144 48 -144 
            ARC N 28 -144 204 32 192 -96 112 -144 
            LINE N 112 -48 48 -48 
        END BLOCKDEF
        BEGIN BLOCKDEF and2b1
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 -48 64 -144 
            LINE N 64 -144 144 -144 
            LINE N 144 -48 64 -48 
            ARC N 96 -144 192 -48 144 -48 144 -144 
            LINE N 256 -96 192 -96 
            LINE N 0 -128 64 -128 
            LINE N 0 -64 40 -64 
            CIRCLE N 40 -76 64 -52 
        END BLOCKDEF
        BEGIN BLOCKDEF fd
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 -112 80 -128 
            LINE N 80 -128 64 -144 
            LINE N 384 -256 320 -256 
            LINE N 0 -256 64 -256 
            LINE N 0 -128 64 -128 
            RECTANGLE N 64 -320 320 -64 
        END BLOCKDEF
        BEGIN BLOCK XLXI_1 or2
            PIN I0 XLXN_2
            PIN I1 XLXN_1
            PIN O S
        END BLOCK
        BEGIN BLOCK XLXI_2 and2b1
            PIN I0 Q
            PIN I1 E1
            PIN O XLXN_1
        END BLOCK
        BEGIN BLOCK XLXI_3 and2b1
            PIN I0 E2
            PIN I1 Q
            PIN O XLXN_2
        END BLOCK
        BEGIN BLOCK XLXI_4 fd
            PIN C Clk
            PIN D S
            PIN Q Q
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 1900 1344
        ATTR LengthUnitName "CM"
        ATTR GridsPerUnit "4"
        INSTANCE XLXI_1 496 528 R0
        INSTANCE XLXI_3 208 608 R0
        INSTANCE XLXI_2 208 448 R0
        BEGIN BRANCH XLXN_1
            WIRE 464 352 480 352
            WIRE 480 352 480 400
            WIRE 480 400 496 400
        END BRANCH
        BEGIN BRANCH XLXN_2
            WIRE 464 512 480 512
            WIRE 480 464 480 512
            WIRE 480 464 496 464
        END BRANCH
        BEGIN BRANCH E1
            WIRE 192 320 208 320
        END BRANCH
        BEGIN BRANCH Q
            WIRE 192 384 208 384
            BEGIN DISPLAY 192 384 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Q
            WIRE 192 480 208 480
            BEGIN DISPLAY 192 480 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH E2
            WIRE 192 544 208 544
        END BRANCH
        BEGIN BRANCH S
            WIRE 752 432 784 432
            WIRE 784 432 848 432
        END BRANCH
        INSTANCE XLXI_4 848 688 R0
        BEGIN BRANCH Clk
            WIRE 816 560 848 560
        END BRANCH
        IOMARKER 816 560 Clk R180 28
        BEGIN BRANCH Q
            WIRE 1232 432 1264 432
        END BRANCH
        IOMARKER 1264 432 Q R0 28
        IOMARKER 192 320 E1 R180 28
        IOMARKER 192 544 E2 R180 28
    END SHEET
END SCHEMATIC
