////////////////////////////////////////////////////////////////////////////////
//   ____  ____   
//  /   /\/   /  
// /___/  \  /   
// \   \   \/  
//  \   \        Copyright (c) 2003-2004 Xilinx, Inc.
//  /   /        All Right Reserved. 
// /---/   /\     
// \   \  /  \  
//  \___\/\___\
////////////////////////////////////////////////////////////////////////////////

#ifndef H_Unisim_nor4_nor4_v_H
#define H_Unisim_nor4_nor4_v_H
#ifdef __MINGW32__
#include "xsimMinGW.h"
#else
#include "xsim.h"
#endif


class Unisim_nor4_nor4_v: public HSim__s6 {
public:

    HSim__s1 SE[5];

  char t196;
  char t197;
  char t198;
  char t199;
    Unisim_nor4_nor4_v(const char * name);
    ~Unisim_nor4_nor4_v();
    void constructObject();
    void constructPorts();
    void reset();
    void architectureInstantiate(HSimConfigDecl* cfg);
    virtual void vhdlArchImplement();
};



HSim__s6 *createUnisim_nor4_nor4_v(const char *name);

#endif
