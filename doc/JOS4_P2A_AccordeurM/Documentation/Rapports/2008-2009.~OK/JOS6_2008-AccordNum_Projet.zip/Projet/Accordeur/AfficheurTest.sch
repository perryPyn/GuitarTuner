VERSION 6
BEGIN SCHEMATIC
    BEGIN ATTR DeviceFamilyName "xbr"
        DELETE all:0
        EDITNAME all:0
        EDITTRAIT all:0
    END ATTR
    BEGIN NETLIST
        SIGNAL ZERO
        SIGNAL UN
        SIGNAL Clk
        SIGNAL Signe
        SIGNAL XLXN_9(7:0)
        SIGNAL Affich(7:0)
        SIGNAL Affich8
        SIGNAL XLXN_13(7:0)
        PORT Input Clk
        PORT Input Signe
        PORT Output Affich(7:0)
        PORT Output Affich8
        PORT Input XLXN_13(7:0)
        BEGIN BLOCKDEF Afficheur
            TIMESTAMP 2009 4 14 15 21 26
            RECTANGLE N 64 -128 320 0 
            RECTANGLE N 0 -108 64 -84 
            LINE N 64 -96 0 -96 
            LINE N 64 -32 0 -32 
            RECTANGLE N 320 -108 384 -84 
            LINE N 320 -96 384 -96 
            LINE N 320 -32 384 -32 
        END BLOCKDEF
        BEGIN BLOCKDEF cb8cled
            TIMESTAMP 2000 1 1 10 10 10
            RECTANGLE N 0 -460 64 -436 
            LINE N 80 -128 64 -144 
            LINE N 64 -112 80 -128 
            LINE N 192 -32 64 -32 
            LINE N 192 -64 192 -32 
            RECTANGLE N 320 -460 384 -436 
            RECTANGLE N 64 -512 320 -64 
            LINE N 384 -192 320 -192 
            LINE N 0 -448 64 -448 
            LINE N 384 -448 320 -448 
            LINE N 0 -256 64 -256 
            LINE N 0 -32 64 -32 
            LINE N 0 -128 64 -128 
            LINE N 0 -192 64 -192 
            LINE N 0 -320 64 -320 
            LINE N 384 -128 320 -128 
        END BLOCKDEF
        BEGIN BLOCKDEF gnd
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 64 -128 64 -96 
            LINE N 64 -64 64 -80 
            LINE N 88 -64 40 -64 
            LINE N 68 -32 60 -32 
            LINE N 76 -48 52 -48 
            LINE N 64 -64 64 -96 
        END BLOCKDEF
        BEGIN BLOCKDEF vcc
            TIMESTAMP 2000 1 1 10 10 10
            LINE N 96 -64 32 -64 
            LINE N 64 0 64 -32 
            LINE N 64 -32 64 -64 
        END BLOCKDEF
        BEGIN BLOCK XLXI_2 cb8cled
            PIN C Clk
            PIN CE UN
            PIN CLR ZERO
            PIN D(7:0) XLXN_13(7:0)
            PIN L ZERO
            PIN UP Signe
            PIN CEO
            PIN Q(7:0) XLXN_9(7:0)
            PIN TC
        END BLOCK
        BEGIN BLOCK XLXI_3 gnd
            PIN G ZERO
        END BLOCK
        BEGIN BLOCK XLXI_4 vcc
            PIN P UN
        END BLOCK
        BEGIN BLOCK XLXI_5 Afficheur
            PIN Etat_mem(7:0) XLXN_9(7:0)
            PIN Signe_mem Signe
            PIN Affich(7:0) Affich(7:0)
            PIN Affich8 Affich8
        END BLOCK
    END NETLIST
    BEGIN SHEET 1 1900 1344
        ATTR LengthUnitName "CM"
        ATTR GridsPerUnit "4"
        INSTANCE XLXI_2 224 784 R0
        INSTANCE XLXI_3 800 352 R0
        INSTANCE XLXI_4 944 288 R0
        BEGIN BRANCH ZERO
            WIRE 864 208 864 224
            BEGIN DISPLAY 864 208 ATTR Name
                ALIGNMENT SOFT-VLEFT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH UN
            WIRE 1008 288 1008 304
            BEGIN DISPLAY 1008 304 ATTR Name
                ALIGNMENT SOFT-VRIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH ZERO
            WIRE 208 752 224 752
            BEGIN DISPLAY 208 752 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Clk
            WIRE 208 656 224 656
        END BRANCH
        BEGIN BRANCH UN
            WIRE 208 592 224 592
            BEGIN DISPLAY 208 592 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH ZERO
            WIRE 208 528 224 528
            BEGIN DISPLAY 208 528 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        BEGIN BRANCH Signe
            WIRE 208 464 224 464
        END BRANCH
        BEGIN BRANCH XLXN_9(7:0)
            WIRE 608 336 608 416
            WIRE 608 416 864 416
            WIRE 864 416 864 528
            WIRE 864 528 880 528
        END BRANCH
        BEGIN BRANCH Signe
            WIRE 864 592 880 592
            BEGIN DISPLAY 864 592 ATTR Name
                ALIGNMENT SOFT-RIGHT
            END DISPLAY
        END BRANCH
        IOMARKER 208 464 Signe R180 28
        BEGIN BRANCH Affich(7:0)
            WIRE 1264 528 1296 528
        END BRANCH
        IOMARKER 1296 528 Affich(7:0) R0 28
        BEGIN BRANCH Affich8
            WIRE 1264 592 1296 592
        END BRANCH
        IOMARKER 1296 592 Affich8 R0 28
        IOMARKER 208 656 Clk R180 28
        BEGIN BRANCH XLXN_13(7:0)
            WIRE 208 336 224 336
        END BRANCH
        IOMARKER 208 336 XLXN_13(7:0) R180 28
        BEGIN INSTANCE XLXI_5 880 624 R0
        END INSTANCE
    END SHEET
END SCHEMATIC
